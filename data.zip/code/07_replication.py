#!/usr/bin/env python3
"""Step 7. Robustness and replication of the exon-level model selection.
(a) cerebellar vermis (independent tissue; Parikshak et al. 2016), covariate-adjusted (no matched composition data);
(b) cortex without composition adjustment; (c) locus-clustered standard errors; (d) leave-one-feature-out scores;
(e) exclusion of microexons (does H-E survive outside the microexon class?).
Output: results/T6_robustness.tsv
"""
import os, sys, numpy as np, pandas as pd, statsmodels.api as sm
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import importlib
ms = importlib.import_module('05_model_selection')
d3 = importlib.import_module('03_asd_dpsi')

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'data', 'processed'); R = os.path.join(ROOT, 'results')

def fit_pair(d, ycol='dpsi', secol='se', cluster=False):
    dd = d[d[ycol].notna() & (d[secol] > 0)]
    w = 1 / dd[secol] ** 2
    out = {}
    for name, cols in {'M0': [], 'H-E': ['Ex'], 'H-K': ['K'], 'H-E+H-K': ['Ex', 'K']}.items():
        X = sm.add_constant(dd[ms.NUIS + cols])
        f = sm.WLS(dd[ycol], X, weights=w).fit(cov_type='cluster', cov_kwds={'groups': dd.locus.values}) if cluster else sm.WLS(dd[ycol], X, weights=w).fit()
        out[name] = f
    r = dict(n=len(dd), dAIC_E_vs_M0=out['M0'].aic - out['H-E'].aic, dAIC_K_vs_M0=out['M0'].aic - out['H-K'].aic,
             dAIC_EK_vs_E=out['H-E'].aic - out['H-E+H-K'].aic, dAIC_EK_vs_K=out['H-K'].aic - out['H-E+H-K'].aic,
             b_E=out['H-E+H-K'].params['Ex'], p_E=out['H-E+H-K'].pvalues['Ex'], b_K=out['H-E+H-K'].params['K'], p_K=out['H-E+H-K'].pvalues['K'],
             t_E=out['H-E+H-K'].tvalues['Ex'], t_K=out['H-E+H-K'].tvalues['K'])
    return r

def cbl_dpsi():
    psi = pd.read_parquet(os.path.join(P, 'psi_cbl.parquet')); meta = pd.read_csv(os.path.join(P, 'meta_cbl.tsv'), sep='\t', index_col=0)
    meta.index = psi.columns
    keep = meta['Detailed.Diagnosis'] != 'Chromosome 15q Duplication Syndrome'
    meta, psi = meta[keep], psi.loc[:, keep.values]
    q = psi.notna().mean(1); mu = psi.mean(1); psi = psi[(q >= 0.8) & (mu > 0.02) & (mu < 0.98)]
    D = pd.DataFrame(index=meta.index)
    D['const'] = 1.0; D['asd'] = (meta['ASD.CTL'] == 'ASD') * 1.0; D['age'] = meta.Age.astype(float); D['male'] = (meta.Sex == 'M') * 1.0
    D['rin'] = meta.RIN.astype(float); D['pmi'] = meta.PMI.astype(float).fillna(meta.PMI.astype(float).median())
    for c in ['SeqBatch', 'BrainBank']:
        D = D.join(pd.get_dummies(meta[c].astype(str), prefix=c, drop_first=True).astype(float))
    D = D.loc[:, (D.std() > 0) | (D.columns == 'const')]
    r = d3.ols_cluster(psi.values, D.values, meta.BrainID.astype(str).values, list(D.columns).index('asd'))
    out = pd.DataFrame(r, index=psi.index, columns=['dpsi_cbl', 'se_cbl', 'G_cbl'])
    out['psi_ctl_cbl'] = psi.loc[:, (meta['ASD.CTL'] == 'CTL').values].mean(1)
    print('cerebellum: samples', psi.shape[1], 'donors', meta.BrainID.nunique(), 'exons', psi.shape[0])
    return out

def main():
    d = ms.load()
    rows = []
    rows.append(dict(analysis='cortex, composition-adjusted (main)', **fit_pair(d)))
    rows.append(dict(analysis='cortex, locus-clustered SE', **fit_pair(d, cluster=True)))
    rows.append(dict(analysis='cortex, no composition adjustment', **fit_pair(d.assign(se_raw=d.se_raw), 'dpsi_raw', 'se_raw')))
    rows.append(dict(analysis='cortex, 10-30 y', **fit_pair(d, 'dpsi_1030', 'se_1030')))
    rows.append(dict(analysis='cortex, microexons excluded', **fit_pair(d[d.micro == 0])))
    rows.append(dict(analysis='cortex, exons >= 51 nt only', **fit_pair(d[d.L >= 51])))
    c = cbl_dpsi(); dc = d.join(c, how='inner')
    p = dc.psi_ctl_cbl.clip(0.01, 0.99)
    for k in range(1, 4): dc[f'p{k}'] = (p - 0.5) ** k
    dc['Ex'] = dc.E * (p * (1 - p)) / (p * (1 - p)).mean()
    rows.append(dict(analysis='cerebellar vermis (replication)', **fit_pair(dc, 'dpsi_cbl', 'se_cbl')))
    T = pd.DataFrame(rows); T.to_csv(os.path.join(R, 'T6_robustness.tsv'), sep='\t', index=False)
    print(T.round(5).to_string())

if __name__ == '__main__':
    main()
