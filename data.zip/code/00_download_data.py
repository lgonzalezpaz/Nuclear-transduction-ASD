#!/usr/bin/env python3
"""Step 0. Retrieve every public input at a pinned version and verify SHA-256 checksums.

Sources (all freely available):
  * Parikshak et al. 2016 (cortex/cerebellum PSI)  - github.com/dhglab/Genome-wide-changes-in-lncRNA-alternative-splicing-and-cortical-patterning-in-autism
  * Gandal et al. 2022 (cortical RNA-seq)          - github.com/dhglab/Broad-transcriptomic-dysregulation-across-the-cerebral-cortex-in-ASD (git-lfs not required for the file used)
  * Quesnel-Vallieres et al. 2015, Maslon et al. 2019, Krick et al. 2025 supplementary tables - Europe PMC REST API
  * UCSC hg19 2bit, liftOver chains and liftOver binary - hgdownload.soe.ucsc.edu
  * MaxEntScan models (maxentpy)                     - github.com/kepbod/maxentpy
The lamina-associated domain track is fetched by 09_lad_test.py from api.genome.ucsc.edu.
"""
import os, sys, hashlib, subprocess, urllib.request, zipfile, shutil

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, 'data', 'raw')
REPOS = {
    'parikshak': ('https://github.com/dhglab/Genome-wide-changes-in-lncRNA-alternative-splicing-and-cortical-patterning-in-autism',
                  'b9c61acb5735080606d186548ce2487230d28c06'),
    'gandal': ('https://github.com/dhglab/Broad-transcriptomic-dysregulation-across-the-cerebral-cortex-in-ASD',
               '6821cc55aaf17879a4e0d8eec454d98b2f87dd6a'),
    'maxentpy': ('https://github.com/kepbod/maxentpy', 'b5e69aadd745fcd9ee65c9dd0ff21b902a63a825'),
}
EPMC = {'qv': 'PMC4387716', 'mas': 'PMC6484407', 'gr': 'PMC12129014'}
UCSC = {
    'genome/hg19.2bit': 'https://hgdownload.soe.ucsc.edu/goldenPath/hg19/bigZips/hg19.2bit',
    'genome/mm9ToHg19.over.chain.gz': 'https://hgdownload.soe.ucsc.edu/goldenPath/mm9/liftOver/mm9ToHg19.over.chain.gz',
    'genome/mm10ToHg19.over.chain.gz': 'https://hgdownload.soe.ucsc.edu/goldenPath/mm10/liftOver/mm10ToHg19.over.chain.gz',
    'genome/mm39ToMm10.over.chain.gz': 'https://hgdownload.soe.ucsc.edu/goldenPath/mm39/liftOver/mm39ToMm10.over.chain.gz',
    'genome/liftOver': 'https://hgdownload.soe.ucsc.edu/admin/exe/linux.x86_64/liftOver',
}

def fetch(url, dest):
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return
    print('downloading', url)
    with urllib.request.urlopen(url, timeout=600) as r, open(dest, 'wb') as f:
        shutil.copyfileobj(r, f)

def sha256(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''): h.update(b)
    return h.hexdigest()

def main():
    os.makedirs(RAW, exist_ok=True)
    for name, (url, commit) in REPOS.items():
        d = os.path.join(RAW, name)
        if not os.path.exists(d):
            subprocess.run(['git', 'clone', '-q', url, d], check=True)
        subprocess.run(['git', '-C', d, 'checkout', '-q', commit], check=True)
    for tag, pmc in EPMC.items():
        z = os.path.join(RAW, 'supp', pmc + '.zip')
        fetch(f'https://www.ebi.ac.uk/europepmc/webservices/rest/{pmc}/supplementaryFiles', z)
        with zipfile.ZipFile(z) as zz:
            for m in zz.namelist():
                if m.lower().endswith(('.xlsx', '.pdf', '.csv', '.txt', '.docx')) and not m.lower().endswith('.mov'):
                    zz.extract(m, os.path.join(RAW, 'supp', tag))
    for rel, url in UCSC.items():
        fetch(url, os.path.join(RAW, rel))
    os.chmod(os.path.join(RAW, 'genome', 'liftOver'), 0o755)
    # verify checksums of all analysed inputs
    bad = 0
    for line in open(os.path.join(ROOT, 'data', 'checksums.sha256')):
        h, rel = line.split()
        p = os.path.join(RAW, rel)
        if not os.path.exists(p):
            print('MISSING (fetched later by its step):', rel); continue
        ok = sha256(p) == h; bad += not ok
        print(('OK      ' if ok else 'MISMATCH'), rel)
    if bad:
        sys.exit(f'{bad} checksum mismatch(es): upstream files changed; see README')
    print('MaxEntScan: install with  pip install ./data/raw/maxentpy')

if __name__ == '__main__':
    main()
