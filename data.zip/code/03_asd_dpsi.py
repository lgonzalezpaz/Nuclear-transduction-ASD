#!/usr/bin/env python3
"""Step 3. Case-control differential exon inclusion in ASD cortex (Parikshak et al. 2016 PSI), adjusted for
biological/technical covariates and for cell-type composition estimated from matched bulk RNA-seq
(Gandal et al. 2022). Also builds donor-level indices: neuronal activity (immediate-early genes), oxidative
phosphorylation capacity (OXPHOS), and the Ca2+/kinase axis.
Outputs: results/exon_dpsi.tsv, data/processed/sample_covariates.tsv
"""
import os, numpy as np, pandas as pd
from scipy import stats

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'data', 'processed'); R = os.path.join(ROOT, 'results'); os.makedirs(R, exist_ok=True)

MARKERS = {
    'neuron': ['SNAP25', 'SYT1', 'RBFOX3', 'STMN2', 'SYN1', 'NEFL', 'VSNL1', 'GABRA1', 'SLC17A7', 'GAD1'],
    'astro': ['GFAP', 'AQP4', 'SLC1A2', 'SLC1A3', 'ALDH1L1', 'GJA1', 'SOX9'],
    'microglia': ['CX3CR1', 'P2RY12', 'CSF1R', 'AIF1', 'TMEM119', 'ITGAM'],
    'oligo': ['MBP', 'PLP1', 'MOG', 'MOBP', 'MAG', 'OLIG2'],
    'endo': ['CLDN5', 'FLT1', 'VWF', 'PECAM1', 'ESAM'],
}
IEG = ['FOS', 'FOSB', 'JUNB', 'EGR1', 'EGR2', 'EGR3', 'NR4A1', 'NR4A3', 'ARC', 'NPAS4', 'DUSP1', 'IER2']
CAAX = ['CAMK4', 'CAMK2A', 'CAMK2B', 'CALM1', 'PPP3CA', 'SRPK1', 'SRPK2', 'CLK1', 'CLK2', 'CLK4']

def gene_symbols(expr_index):
    """Map Ensembl gene IDs to HGNC symbols using the annotation of Parikshak et al. 2016 (Supplementary Table 2A)."""
    a = pd.read_csv(os.path.join(ROOT, 'data', 'raw', 'parikshak', 'data', 'provided', 'SuppTable2A.csv'), usecols=[0, 1])
    mp = dict(zip(a.iloc[:, 0].astype(str), a.iloc[:, 1].astype(str)))
    return [mp.get(i.split('.')[0], i) for i in expr_index]

def zscore_score(E, genes):
    g = [x for x in genes if x in E.index]
    Z = E.loc[g]; Z = Z.sub(Z.mean(1), axis=0).div(Z.std(1) + 1e-9, axis=0)
    return Z.mean(0), len(g)

def ols_cluster(Y, X, groups, coef_idx):
    """Per-row OLS of Y (exons x samples, NaN allowed) on X (samples x k) with CR1 donor-clustered SE."""
    out = np.full((Y.shape[0], 3), np.nan)
    for i in range(Y.shape[0]):
        y = Y[i]; m = ~np.isnan(y)
        Xi = X[m]; yi = y[m]; gi = groups[m]
        n, k = Xi.shape
        if n < k + 10: continue
        XtXi = np.linalg.pinv(Xi.T @ Xi); b = XtXi @ Xi.T @ yi; e = yi - Xi @ b
        a = (XtXi @ Xi.T)[coef_idx]
        G = np.unique(gi); s = np.array([np.sum(a[gi == g] * e[gi == g]) for g in G])
        var = len(G) / (len(G) - 1) * (n - 1) / (n - k) * np.sum(s ** 2)
        out[i] = [b[coef_idx], np.sqrt(var), len(G)]
    return out

def design(meta, cell=None):
    D = pd.DataFrame(index=meta.index)
    D['asd'] = (meta['ASD.CTL'] == 'ASD').astype(float)
    D['age'] = meta.Age.astype(float); D['male'] = (meta.Sex == 'M').astype(float)
    D['rin'] = meta.RIN.astype(float); D['pmi'] = meta.PMI.astype(float).fillna(meta.PMI.astype(float).median())
    D['ba9'] = (meta.RegionID == 'ba9').astype(float)
    for c in ['SeqBatch', 'BrainBank']:
        d = pd.get_dummies(meta[c].astype(str), prefix=c, drop_first=True).astype(float); D = D.join(d)
    if cell is not None:
        D = D.join(cell)
    D.insert(0, 'const', 1.0)
    return D

def main():
    ex = pd.read_csv(os.path.join(P, 'exons_features.tsv'), sep='\t', index_col=0)
    psi = pd.read_parquet(os.path.join(P, 'psi_ctx.parquet'))
    meta = pd.read_csv(os.path.join(P, 'meta_ctx.tsv'), sep='\t', index_col=0)
    meta.index = psi.columns
    keep = meta['Detailed.Diagnosis'] != 'Chromosome 15q Duplication Syndrome'
    meta = meta[keep]; psi = psi.loc[:, meta.index]
    psi = psi.loc[psi.index.isin(ex.index)]
    # exon filter: quantified in >=80% samples, mean PSI 0.02-0.98
    q = psi.notna().mean(1); mu = psi.mean(1)
    psi = psi[(q >= 0.8) & (mu > 0.02) & (mu < 0.98)]
    print('samples', psi.shape[1], 'donors', meta.BrainID.nunique(), 'ASD donors',
          meta.loc[meta['ASD.CTL'] == 'ASD', 'BrainID'].nunique(), 'exons', psi.shape[0],
          'microexons', int(ex.loc[psi.index, 'micro'].sum()))
    # matched bulk expression -> composition, activity and energetic indices
    if not os.path.exists(os.path.join(P, 'gandal_expr.parquet')):   # cache the Gandal et al. 2022 RData once
        import pyreadr
        g = pyreadr.read_r(os.path.join(ROOT, 'data', 'raw', 'gandal', 'data_provided', '02_DEGenesIsoforms',
                                        '02_01_A_AllProcessedData_wModelMatrix.RData'))
        g['datExpr'].to_parquet(os.path.join(P, 'gandal_expr.parquet')); g['datMeta'].to_csv(os.path.join(P, 'gandal_meta.tsv'), sep='\t')
    E = pd.read_parquet(os.path.join(P, 'gandal_expr.parquet')); gm = pd.read_csv(os.path.join(P, 'gandal_meta.tsv'), sep='\t', index_col=0)
    E.index = gene_symbols(E.index); E = E.groupby(level=0).mean()
    oxphos = [g for g in E.index if g.startswith(('NDUFA', 'NDUFB', 'NDUFS', 'NDUFV', 'SDHA', 'SDHB', 'SDHC', 'SDHD', 'UQCR',
                                                   'COX4I1', 'COX5A', 'COX5B', 'COX6A1', 'COX6B1', 'COX6C', 'COX7A2', 'COX7B', 'COX7C', 'COX8A', 'ATP5'))]
    sc = {}
    for k, g in MARKERS.items(): sc[k], _ = zscore_score(E, g)
    sc['ieg'], nieg = zscore_score(E, IEG); sc['oxphos'], nox = zscore_score(E, oxphos); sc['caax'], nca = zscore_score(E, CAAX)
    for g in ['SRRM4', 'SRRM3', 'RBFOX1', 'SRSF11', 'RNPS1', 'CPEB4', 'POLR2A', 'SETD2', 'KAT2A', 'HDAC2']:
        if g in E.index: sc['g_' + g] = E.loc[g]
    S = pd.DataFrame(sc)
    print('genes in indices: IEG', nieg, 'OXPHOS', nox, 'Ca/kinase', nca)
    S['subject'] = gm.subject.astype(str).values; S['region'] = gm.region.astype(str).str.upper().values
    S = S.groupby(['subject', 'region']).mean()
    key = list(zip(meta.BrainID.astype(str), meta.RegionID.astype(str).str.upper().str.replace('BA41-42-22', 'BA41-42-22')))
    cov = pd.DataFrame([S.loc[k].values if k in S.index else [np.nan] * S.shape[1] for k in key], index=meta.index, columns=S.columns)
    cov.to_csv(os.path.join(P, 'sample_covariates.tsv'), sep='\t')
    matched = cov.neuron.notna()
    print('samples matched to bulk RNA-seq:', int(matched.sum()))
    groups = meta.BrainID.astype(str).values
    res = pd.DataFrame(index=psi.index)
    res['psi_ctl'] = psi.loc[:, (meta['ASD.CTL'] == 'CTL').values].mean(1)
    res['psi_asd'] = psi.loc[:, (meta['ASD.CTL'] == 'ASD').values].mean(1)
    # (i) covariates only, all samples
    D0 = design(meta); r0 = ols_cluster(psi.values, D0.values, groups, 1)
    res['dpsi_raw'], res['se_raw'], res['G_raw'] = r0.T
    # (ii) + cell-type composition on matched samples
    mm = meta[matched]; D1 = design(mm, cov.loc[matched, list(MARKERS)])
    r1 = ols_cluster(psi.loc[:, matched.values].values, D1.values, mm.BrainID.astype(str).values, 1)
    res['dpsi'], res['se'], res['G'] = r1.T
    # (iii) adolescents/young adults (10-30 y), composition-adjusted
    ya = matched & (meta.Age > 10) & (meta.Age <= 30)
    my = meta[ya]; D2 = design(my, cov.loc[ya, list(MARKERS)])
    D2 = D2.loc[:, D2.std() > 0].copy(); D2.insert(0, 'const', 1.0) if 'const' not in D2 else None
    cols = list(D2.columns); ia = cols.index('asd')
    r2 = ols_cluster(psi.loc[:, ya.values].values, D2.values, my.BrainID.astype(str).values, ia)
    res['dpsi_1030'], res['se_1030'], res['G_1030'] = r2.T
    res['t'] = res.dpsi / res.se; res['p'] = 2 * stats.t.sf(np.abs(res.t), res.G - 1)
    res = res.join(ex)
    res.to_csv(os.path.join(R, 'exon_dpsi.tsv'), sep='\t')
    mi = res.micro == 1
    print('microexons with lower inclusion (adj):', f'{(res.loc[mi, "dpsi"] < 0).mean():.3f}', 'n=', mi.sum(),
          '| longer exons:', f'{(res.loc[~mi, "dpsi"] < 0).mean():.3f}')

if __name__ == '__main__':
    main()
