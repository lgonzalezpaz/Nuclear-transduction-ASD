#!/usr/bin/env python3
"""Step 4. Transduction-channel signatures at exon resolution.

E-score (H-E): cis-encoded dependence on the SRRM4/eMIC microexon-activation scaffold, learned from Srrm4-knockout
               cortex/hippocampus (Quesnel-Vallieres et al. 2015) and applied genome-wide (cross-species transfer).
K-score (H-K): cis-encoded sensitivity to RNA Pol II elongation rate, learned from slow Pol II (R749H) motor neurons
               (Maslon et al. 2019).
Both models use the same 15 sequence/architecture features, the same learner family and gene-grouped
cross-validation, so neither hypothesis is favoured by construction.
Outputs: results/exon_scores.tsv, results/signature_models.tsv
"""
import os, numpy as np, pandas as pd
from scipy import stats
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import GroupKFold
from sklearn.metrics import roc_auc_score

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'data', 'processed'); R = os.path.join(ROOT, 'results')
FEATS = ['logL', 'micro', 'me3', 'me5', 'me3_down', 'me5_up', 'logLup', 'logLdn', 'ugc', 'pyr', 'gcatg_dn',
         'gcatg_up', 'gc_exon', 'gc_flank', 'frame']

def loci(df):
    """Group exons into loci (proxy for genes) by overlap of their flanking-exon spans."""
    lab = pd.Series(-1, index=df.index); k = 0
    for c, g in df.groupby('chrom'):
        g = g.assign(a=np.minimum(g.ueS, g.deS), b=np.maximum(g.ueE, g.deE)).sort_values('a')
        end = -1
        for i, r in g.iterrows():
            if r.a > end: k += 1
            lab[i] = k; end = max(end, r.b)
    return lab

def main():
    d = pd.read_csv(os.path.join(R, 'exon_dpsi.tsv'), sep='\t', index_col=0)
    ms = pd.read_csv(os.path.join(P, 'mouse_sets_hg19.tsv'), sep='\t', index_col=0)
    ms.columns = [c.replace('.', '_') for c in ms.columns]
    ex = pd.read_csv(os.path.join(P, 'exons_features.tsv'), sep='\t', index_col=0)
    ex = ex[ex.in_ctx == 1].join(ms)
    ex['logL'] = np.log10(ex.L); ex['logLup'] = np.log10(ex.Lup + 1); ex['logLdn'] = np.log10(ex.Ldn + 1)
    ex[FEATS] = ex[FEATS].fillna(ex[FEATS].median())
    ex['locus'] = loci(ex)
    out = []
    # --- E-score: Srrm4 dependence (positives: reduced inclusion in Srrm4 KO; background: exons quantified by
    #     VAST-TOOLS in Maslon et al. that are not Srrm4-dependent) ---
    univ = ex[ex.slow_EVENT.notna() | ex.srrm4_event.notna()].copy()
    univ['y'] = (univ.srrm4_dPSI < 0).astype(int)
    X, y, g = univ[FEATS].values, univ.y.values, univ.locus.values
    mE = make_pipeline(StandardScaler(), LogisticRegression(C=0.3, class_weight='balanced', max_iter=5000))
    pred = np.zeros(len(y))
    for tr, te in GroupKFold(5).split(X, y, g):
        mE.fit(X[tr], y[tr]); pred[te] = mE.predict_proba(X[te])[:, 1]
    aucE = roc_auc_score(y, pred)
    pd.DataFrame({'y': y, 'cv_pred': pred}, index=univ.index).to_csv(os.path.join(R, 'cv_E.tsv'), sep='\t')
    mE.fit(X, y); ex['E_score'] = mE.predict_proba(ex[FEATS].values)[:, 1]
    coefE = pd.Series(mE[-1].coef_[0], index=FEATS)
    out.append(dict(model='E (Srrm4-KO)', n=len(y), n_pos=int(y.sum()), cv_metric='AUC', cv_value=aucE))
    print(f'E-score: n={len(y)} positives={y.sum()} gene-grouped CV AUC={aucE:.3f}')
    # --- K-score: elongation-rate sensitivity (slow Pol II motor neurons) ---
    k = ex[ex.slow_dPSI_ms_mw.notna()].copy()
    X, y, g = k[FEATS].values, k.slow_dPSI_ms_mw.values / 100, k.locus.values
    mK = make_pipeline(StandardScaler(), Ridge(alpha=10.0))
    pred = np.zeros(len(y))
    for tr, te in GroupKFold(5).split(X, y, g):
        mK.fit(X[tr], y[tr]); pred[te] = mK.predict(X[te])
    rK = stats.spearmanr(pred, y)[0]
    pd.DataFrame({'y': y, 'cv_pred': pred, 'micro': k.micro.values}, index=k.index).to_csv(os.path.join(R, 'cv_K.tsv'), sep='\t')
    mK.fit(X, y); ex['K_score'] = mK.predict(ex[FEATS].values)
    coefK = pd.Series(mK[-1].coef_, index=FEATS)
    out.append(dict(model='K (slow Pol II MN)', n=len(y), n_pos=np.nan, cv_metric='Spearman', cv_value=rK))
    print(f'K-score: n={len(y)} gene-grouped CV Spearman={rK:.3f}')
    # neuronal-differentiation axis (WT motor neurons vs WT ESC) as nuisance signature
    kk = k[k.slow_dPSI_mw_ew.notna()]
    X, y = kk[FEATS].values, kk.slow_dPSI_mw_ew.values / 100
    mD = make_pipeline(StandardScaler(), Ridge(alpha=10.0)).fit(X, y); ex['D_score'] = mD.predict(ex[FEATS].values)
    print('score correlations (Spearman):\n', ex[['E_score', 'K_score', 'D_score']].corr('spearman').round(3))
    pd.DataFrame({'E_coef': coefE, 'K_coef': coefK}).to_csv(os.path.join(R, 'signature_coefficients.tsv'), sep='\t')
    pd.DataFrame(out).to_csv(os.path.join(R, 'signature_models.tsv'), sep='\t', index=False)
    ex[['locus', 'E_score', 'K_score', 'D_score']].to_csv(os.path.join(R, 'exon_scores.tsv'), sep='\t')
    print(pd.DataFrame({'E_coef': coefE, 'K_coef': coefK}).round(3))

if __name__ == '__main__':
    main()
