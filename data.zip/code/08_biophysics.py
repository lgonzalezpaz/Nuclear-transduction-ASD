#!/usr/bin/env python3
"""Step 8. First-principles biophysics of the three transduction channels, confronted with human data.

A  Observed age-resolved microexon deficit (composition-adjusted) in this cohort.
B  Activity load of the under-pruned circuit (mean-field activity map) from human spine densities (Tang et al. 2014).
C  Energetic budget: ATP demand and steady-state ATP of an over-connected neuron.
D  Condensate (lever-rule) model of the microexon-activation scaffold: emergent ultrasensitivity.
E  Elongation-rate model: magnitude and sign required to explain the deficit, calibrated on slow Pol II neurons.
F  Prior-predictive (rejection) comparison of H-E(Ca), H-E(ATP) and H-K against the age profile and the donor-level
   distribution; mechanical null by Monte Carlo; variance-based (Sobol) sensitivity.
Outputs: results/biophysics_*.tsv
"""
import os, sys, numpy as np, pandas as pd, statsmodels.api as sm
from scipy import stats
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import biophys as B

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'data', 'processed'); R = os.path.join(ROOT, 'results')
rng = np.random.default_rng(42)
MARK = ['neuron', 'astro', 'microglia', 'oligo', 'endo']

# Tang et al. 2014 (Golgi, temporal cortex layer V): ASD/control spine-density ratios (mean +/- s.e.)
SPINE = {'child': (1.084, 0.037), 'adol': (1.655, 0.088)}

def observed_age_profile():
    psi = pd.read_parquet(os.path.join(P, 'psi_ctx.parquet'))
    meta = pd.read_csv(os.path.join(P, 'meta_ctx.tsv'), sep='\t', index_col=0); meta.index = psi.columns
    cov = pd.read_csv(os.path.join(P, 'sample_covariates.tsv'), sep='\t', index_col=0).reindex(psi.columns)
    ex = pd.read_csv(os.path.join(R, 'exon_dpsi.tsv'), sep='\t', index_col=0)
    keep = (meta['Detailed.Diagnosis'] != 'Chromosome 15q Duplication Syndrome') & cov.neuron.notna()
    meta, cov, psi = meta[keep], cov[keep], psi.loc[:, keep.values]
    mic = ex[(ex.micro == 1) & (ex.psi_ctl > 0.5)].index
    y = psi.loc[mic].mean(0)
    rows = []
    for lab, lo, hi in [('<=10 y', 0, 10), ('10-30 y', 10, 30), ('>30 y', 30, 200)]:
        m = (meta.Age > lo) & (meta.Age <= hi) if lo > 0 else (meta.Age <= hi)
        X = pd.DataFrame({'asd': (meta['ASD.CTL'] == 'ASD') * 1.0, 'age': meta.Age, 'ba9': (meta.RegionID == 'ba9') * 1.0,
                          'rin': meta.RIN}, index=meta.index).join(cov[MARK])[m]
        f = sm.OLS(y[m], sm.add_constant(X)).fit(cov_type='cluster', cov_kwds={'groups': meta.BrainID[m].values})
        rows.append(dict(band=lab, n_samples=int(m.sum()), n_donors=meta.BrainID[m].nunique(), dpsi=f.params['asd'], se=f.bse['asd'], p=f.pvalues['asd']))
    T = pd.DataFrame(rows); print('observed microexon deficit by age\n', T.round(4)); return T, len(mic)

def draw_priors(n):
    u = lambda a, b: rng.uniform(a, b, n)
    lu = lambda a, b: np.exp(rng.uniform(np.log(a), np.log(b), n))
    return pd.DataFrame(dict(
        # mean-field activity map: literature-informed ranges (see Table 1 of the article)
        Cb=u(0.05, 0.30),        # share of activity not driven by local recurrent synapses
        q=u(1.0, 2.5),           # supralinearity of recurrent drive
        eta=u(0.5, 1.5),         # efficacy of the homeostatic brake (synaptic scaling)
        kappa=u(0.0, 1.0),       # strength of the homeostatic response
        KC=u(1.0, 3.0),          # half-activation of the nuclear Ca2+/CaMK pathway (relative activity)
        n=u(2.0, 5.0),           # cooperativity of Ca2+/calmodulin activation (four Ca2+ sites)
        Nchild=rng.normal(*SPINE['child'], n), Nadol=rng.normal(*SPINE['adol'], n),
        # Ca2+/kinase -> scaffold
        phi0=u(0.05, 0.5),       # fraction of scaffold inactivated at the activity set point (activity lowers nSR100)
        gamma=u(0.5, 5.0),       # e-fold rise of c_sat per unit phosphorylated fraction
        rho0=u(1.2, 4.0),        # baseline supersaturation c/c_sat
        h0=u(1.0, 2.0), K0=u(0.2, 0.6),  # intrinsic (molecular) cooperativity and half-activation of inclusion
        # energetics
        SRC=u(1.3, 3.0), chronic=u(0.0, 0.9), mu=u(0.0, 3.0),
        # elongation
        kv=u(0.0, np.log(2)),    # literature sign: depolarisation accelerates elongation (Schor et al. 2009)
        kv_sym=u(-np.log(2), np.log(2)),
    ))

def simulate(th, Imax=0.79, s_micro=None):
    """Return predicted microexon dPSI (child, adolescent) for each channel and intermediate quantities."""
    out = {}
    for age in ['child', 'adol']:
        Nr = th['N' + age].values
        C = np.array([B.activity_from_spines(max(nr, 0.5), cb, q, et, ka, kc, nn) for nr, cb, q, et, ka, kc, nn in
                      zip(Nr, th.Cb, th.q, th.eta, th.kappa, th.KC, th.n)])
        out[f'C_{age}'] = C
        A = B.hill(C, th.KC.values, th.n.values); A1 = B.hill(1.0, th.KC.values, th.n.values)
        phi = np.clip(th.phi0.values * A / A1, 0, 1)
        j = B.atp_demand(C, Nr); a = B.atp_ratio(j, th.SRC.values, chronic=th.chronic.values)
        out[f'j_{age}'] = j; out[f'atp_{age}'] = a
        base = B.micro_psi(1.0, Imax, th.K0.values, th.h0.values)
        S_ca = B.s_eff(phi, 1.0, th.rho0.values, th.gamma.values, 0.0, th.phi0.values)
        S_atp = B.s_eff(th.phi0.values, a, th.rho0.values, th.gamma.values, th.mu.values, th.phi0.values)
        S_both = B.s_eff(phi, a, th.rho0.values, th.gamma.values, th.mu.values, th.phi0.values)
        out[f'HE_ca_{age}'] = B.micro_psi(S_ca, Imax, th.K0.values, th.h0.values) - base
        out[f'HE_atp_{age}'] = B.micro_psi(S_atp, Imax, th.K0.values, th.h0.values) - base
        out[f'HE_{age}'] = B.micro_psi(S_both, Imax, th.K0.values, th.h0.values) - base
        dlnv = (A - A1) / (1 - A1)
        out[f'HK_{age}'] = s_micro * th.kv.values * dlnv
        out[f'HKsym_{age}'] = s_micro * th.kv_sym.values * dlnv
    return pd.DataFrame(out)

def main():
    global CAL
    CAL = pd.read_csv(os.path.join(R, 'transfer_calibration.tsv'), sep='\t', index_col=0).iloc[:, 0].to_dict()
    obs, nmic = observed_age_profile(); obs.to_csv(os.path.join(R, 'biophysics_observed_age.tsv'), sep='\t', index=False)
    # elongation sensitivity of neural microexons from slow Pol II motor neurons
    t = pd.read_excel(os.path.join(ROOT, 'data', 'raw', 'supp', 'mas', 'EMBJ-38-e101244-s003.xlsx'), header=1)
    a = t.iloc[:, [0, 3]].dropna(); a.columns = ['tx', 'wt']; b = t.iloc[:, [18, 21]].dropna(); b.columns = ['tx', 'slow']
    m = a.merge(b, on='tx'); m = m[(m.wt > 0) & (m.slow > 0)]
    dlnv_slow = np.log(np.median(m.slow / m.wt))
    ex = pd.read_csv(os.path.join(R, 'exon_dpsi.tsv'), sep='\t', index_col=0)
    mo = pd.read_csv(os.path.join(P, 'mouse_sets_hg19.tsv'), sep='\t', index_col=0); mo.columns = [c.replace('.', '_') for c in mo.columns]
    e = ex.join(mo); mm = e[(e.micro == 1) & e.slow_dPSI_ms_mw.notna()]
    boot = [np.median(rng.choice(mm.slow_dPSI_ms_mw.values, len(mm))) for _ in range(2000)]
    s_micro = (np.median(mm.slow_dPSI_ms_mw) / 100) / dlnv_slow
    print(f'paired elongation ratio slow/WT = {np.exp(dlnv_slow):.3f} (n={len(m)} genes; dlnv={dlnv_slow:.3f});'
          f' microexon dPSI in slow MN median {np.median(mm.slow_dPSI_ms_mw):.2f} (95% CI {np.percentile(boot,2.5):.2f},{np.percentile(boot,97.5):.2f}; n={len(mm)})'
          f' -> dPSI/dlnv = {s_micro:.3f}')
    # required elongation changes
    target = obs.loc[obs.band == '10-30 y', 'dpsi'].values[0]
    req = pd.DataFrame([dict(quantity='paired slow/WT elongation ratio', value=np.exp(dlnv_slow), n=len(m)),
                        dict(quantity='dlnv slow vs WT', value=dlnv_slow, n=len(m)),
                        dict(quantity='microexon dPSI in slow MN (median, PSI units)', value=np.median(mm.slow_dPSI_ms_mw) / 100, n=len(mm)),
                        dict(quantity='dPSI_micro / dlnv', value=s_micro, n=len(mm)),
                        dict(quantity='dlnv required for 10-30 y deficit', value=target / s_micro, n=np.nan),
                        dict(quantity='dlnv required for the subgroup deficit (mixture delta, this study)', value=CAL['delta'] / s_micro, n=np.nan)])
    req.to_csv(os.path.join(R, 'biophysics_elongation.tsv'), sep='\t', index=False); print(req.round(4))
    # prior-predictive simulation
    N = 40000
    th = draw_priors(N); sim = simulate(th, s_micro=s_micro)
    allp = pd.concat([th, sim], axis=1); allp.to_csv(os.path.join(R, 'biophysics_draws.tsv.gz'), sep='\t', index=False, compression='gzip')
    oc, sc_ = obs.loc[obs.band == '<=10 y', ['dpsi', 'se']].values[0]; oa, sa = obs.loc[obs.band == '10-30 y', ['dpsi', 'se']].values[0]
    rows = []
    for ch, lab in [('HE_ca', 'H-E (Ca2+/phosphorylation -> condensate)'), ('HE_atp', 'H-E (ATP supply-demand only)'),
                    ('HE', 'H-E (Ca2+ + ATP)'), ('HK', 'H-K (activity accelerates Pol II; literature sign)'),
                    ('HKsym', 'H-K (sign-agnostic elongation change)')]:
        pc, pa = sim[f'{ch}_child'].values, sim[f'{ch}_adol'].values
        # Gaussian likelihood of the two age bands; marginal likelihood by prior averaging
        L = stats.norm.pdf(pc, oc, sc_) * stats.norm.pdf(pa, oa, sa)
        acc = np.abs((pc - oc) / sc_) ** 2 + np.abs((pa - oa) / sa) ** 2 <= 2 ** 2
        rows.append(dict(channel=lab, marg_lik=L.mean(), accept_2SE=acc.mean(),
                         median_child=np.median(pc), median_adol=np.median(pa), q05_adol=np.quantile(pa, 0.05), q95_adol=np.quantile(pa, 0.95),
                         frac_adol_below_obs=(pa <= oa).mean(), frac_sign_correct=(pa < 0).mean()))
    T = pd.DataFrame(rows); T['BF_vs_best'] = T.marg_lik / T.marg_lik.max()
    T.to_csv(os.path.join(R, 'biophysics_channel_comparison.tsv'), sep='\t', index=False); print(T.round(4).to_string())
    q = dict(C_child=np.median(sim.C_child), C_adol=np.median(sim.C_adol), C_adol_q05=np.quantile(sim.C_adol, .05), C_adol_q95=np.quantile(sim.C_adol, .95),
             j_adol=np.median(sim.j_adol), j_adol_q95=np.quantile(sim.j_adol, .95), atp_adol=np.median(sim.atp_adol), atp_adol_q05=np.quantile(sim.atp_adol, .05),
             atp_adol_acute=np.median(B.atp_ratio(sim.j_adol, th.SRC, chronic=0)))
    pd.Series(q).to_csv(os.path.join(R, 'biophysics_load.tsv'), sep='\t'); print(pd.Series(q).round(3))
    # energetic feasibility: fraction of draws in which adolescent ATP demand exceeds spare respiratory capacity
    feas = dict(frac_demand_exceeds_SRC=(sim.j_adol >= th.SRC).mean(), median_j_adol=np.median(sim.j_adol),
                frac_atp_drop_gt20pct_chronic=(sim.atp_adol < 0.8).mean())
    pd.Series(feas).to_csv(os.path.join(R, 'biophysics_energetic_feasibility.tsv'), sep='\t'); print(pd.Series(feas).round(3))
    # rejection ABC on the age profile (2 s.e. ellipse); posterior of the condensate parameters
    post = {}
    for ch in ['HE_ca', 'HKsym', 'HE_atp']:
        pc, pa = sim[f'{ch}_child'].values, sim[f'{ch}_adol'].values
        acc = ((pc - oc) / sc_) ** 2 + ((pa - oa) / sa) ** 2 <= 4
        post[ch] = np.where(acc)[0]
    PQ = []
    for ch, ii in post.items():
        for par in ['gamma', 'rho0', 'phi0', 'kv_sym', 'SRC', 'chronic', 'mu']:
            PQ.append(dict(channel=ch, parameter=par, n_acc=len(ii), prior_median=th[par].median(), post_median=np.median(th[par].values[ii]) if len(ii) else np.nan,
                           post_q05=np.quantile(th[par].values[ii], .05) if len(ii) else np.nan, post_q95=np.quantile(th[par].values[ii], .95) if len(ii) else np.nan))
    PQ = pd.DataFrame(PQ); PQ.to_csv(os.path.join(R, 'biophysics_abc_posterior.tsv'), sep='\t', index=False)
    print(PQ[PQ.parameter.isin(['gamma', 'rho0', 'phi0', 'kv_sym'])].round(3).to_string())
    # margin to dissolution: ln(rho0)/gamma - (phi_adol - phi0) for accepted H-E(Ca) draws
    ii = post['HE_ca']
    A = B.hill(sim.C_adol.values[ii], th.KC.values[ii], th.n.values[ii]); A1 = B.hill(1.0, th.KC.values[ii], th.n.values[ii])
    dphi = np.clip(th.phi0.values[ii] * A / A1, 0, 1) - th.phi0.values[ii]
    margin = np.log(th.rho0.values[ii]) / th.gamma.values[ii]
    crit = pd.Series(dict(n_accepted=len(ii), median_dphi_adol=np.median(dphi), median_margin=np.median(margin),
                          median_fraction_of_margin_used=np.median(dphi / margin)))
    crit.to_csv(os.path.join(R, 'biophysics_criticality.tsv'), sep='\t'); print(crit.round(3))
    # subgroup prediction: inter-individual variation in scaffold dosage moves individuals relative to the
    # dissolution threshold (lever rule: collapse when gamma*dphi >= ln(rho0_i)); rho0_i = rho0 * 2^x_i with x_i the
    # donor-level log2 SRRM4 expression per neuron (control s.d., composition-adjusted; Gandal et al. 2022)
    cov = pd.read_csv(os.path.join(P, 'sample_covariates.tsv'), sep='\t', index_col=0)
    meta = pd.read_csv(os.path.join(P, 'meta_ctx.tsv'), sep='\t', index_col=0)
    meta.index = pd.read_parquet(os.path.join(P, 'psi_ctx.parquet')).columns
    cm = cov.join(meta[['BrainID', 'ASD.CTL', 'Age', 'RegionID']]).dropna(subset=['g_SRRM4', 'neuron'])
    cc = cm[cm['ASD.CTL'] == 'CTL']
    f = sm.OLS(cc.g_SRRM4, sm.add_constant(pd.DataFrame({'neuron': cc.neuron, 'age': cc.Age, 'ba9': (cc.RegionID == 'ba9') * 1.0}))).fit()
    sd_srrm4 = cc.assign(r=f.resid).groupby('BrainID').r.mean().std()
    ii = post['HE_ca']; nd = 2000
    def subgroup(sd, ndraw):
        fr, dd = [], []
        for k in rng.choice(ii, min(ndraw, len(ii)), replace=False):
            Nr = rng.normal(SPINE['adol'][0], SPINE['adol'][1] * np.sqrt(5), 200).clip(0.8)
            C = np.resize(np.array([B.activity_from_spines(x, th.Cb[k], th.q[k], th.eta[k], th.kappa[k], th.KC[k], th.n[k]) for x in Nr]), nd)
            A = B.hill(C, th.KC[k], th.n[k]); A1 = B.hill(1.0, th.KC[k], th.n[k])
            phi = np.clip(th.phi0[k] * A / A1, 0, 1)
            rho_i = th.rho0[k] * 2 ** rng.normal(0, sd, nd)
            own = np.maximum(rho_i - 1, 1e-9) / (th.rho0[k] - 1)
            S = B.s_eff(phi, 1.0, rho_i, th.gamma[k], 0.0, th.phi0[k])
            dpsi = B.micro_psi(S, 0.79, th.K0[k], th.h0[k]) - B.micro_psi(own, 0.79, th.K0[k], th.h0[k])
            crossed = (rho_i > 1) & (S < 0.5 * own)      # condensate-competent at baseline, lost >50% under load
            fr.append(crossed.mean()); dd.append(dpsi[crossed].mean() if crossed.any() else np.nan)
        return np.array(fr), np.array(dd)
    fr, dd = subgroup(sd_srrm4, 1000)
    scan = []
    for sd in [sd_srrm4, 0.6, 0.9, 1.2, 1.5, 2.0]:
        f2, d2 = subgroup(sd, 300); scan.append(dict(sd_log2=sd, frac_median=np.median(f2), frac_q05=np.quantile(f2, .05), frac_q95=np.quantile(f2, .95), dpsi_sub=np.nanmedian(d2)))
    pd.DataFrame(scan).to_csv(os.path.join(R, 'biophysics_subgroup_scan.tsv'), sep='\t', index=False); print(pd.DataFrame(scan).round(3))
    sub = pd.Series(dict(sd_log2_SRRM4_donor=sd_srrm4, pred_subgroup_frac_median=np.median(fr), pred_subgroup_frac_q05=np.quantile(fr, .05),
                         pred_subgroup_frac_q95=np.quantile(fr, .95), pred_subgroup_dpsi_median=np.nanmedian(dd)))
    sub.to_csv(os.path.join(R, 'biophysics_subgroup.tsv'), sep='\t'); print(sub.round(4))
    # emergent ultrasensitivity of the condensate transfer function
    hh = []
    for k in rng.choice(N, 2000, replace=False):
        h, K = B.effective_hill(th.rho0[k], th.K0[k], th.h0[k]); hh.append(dict(rho0=th.rho0[k], h0=th.h0[k], K0=th.K0[k], h_eff=h, K_eff=K))
    H = pd.DataFrame(hh); H.to_csv(os.path.join(R, 'biophysics_emergent_hill.tsv'), sep='\t', index=False)
    print('emergent Hill: median', H.h_eff.median(), '90% range', H.h_eff.quantile([.05, .95]).values, 'K_eff median', H.K_eff.median(),
          f"frac within the calibrated 95% interval [{CAL['h_lo']}, {CAL['h_hi']}]", ((H.h_eff >= CAL['h_lo']) & (H.h_eff <= CAL['h_hi'])).mean())
    pd.Series(dict(h_eff_median=H.h_eff.median(), h_eff_q05=H.h_eff.quantile(.05), h_eff_q95=H.h_eff.quantile(.95), K_eff_median=H.K_eff.median(),
                   K_eff_q05=H.K_eff.quantile(.05), K_eff_q95=H.K_eff.quantile(.95),
                   frac_within_calibrated=((H.h_eff >= CAL['h_lo']) & (H.h_eff <= CAL['h_hi'])).mean())).to_csv(os.path.join(R, 'biophysics_emergent_hill_summary.tsv'), sep='\t')
    # mechanical null
    md = pd.DataFrame(B.mech_draws(200000, rng))
    mq = dict(median_dF_pN=np.median(md.dF) * 1e12, q99_dF_pN=np.quantile(md.dF, .99) * 1e12, median_ratio=np.median(md.ratio),
              q99_ratio=np.quantile(md.ratio, .99), frac_ratio_gt_1pct=(md.ratio > 0.01).mean(), frac_ratio_gt_5pct=(md.ratio > 0.05).mean(),
              median_attenuation=np.median(np.exp(-md.dist / md.lam)))
    pd.Series(mq).to_csv(os.path.join(R, 'biophysics_mechanical.tsv'), sep='\t'); print(pd.Series(mq))
    md.sample(20000, random_state=1).to_csv(os.path.join(R, 'biophysics_mechanical_draws.tsv.gz'), sep='\t', index=False, compression='gzip')
    # Sobol sensitivity of the adolescent microexon deficit (H-E, Ca + ATP) and of the ATP ratio
    from SALib.sample import sobol as ssob
    from SALib.analyze import sobol as asob
    names = ['Cb', 'q', 'eta', 'kappa', 'KC', 'n', 'Nadol', 'phi0', 'gamma', 'rho0', 'h0', 'K0', 'SRC', 'chronic', 'mu']
    bounds = [[0.05, 0.30], [1.0, 2.5], [0.5, 1.5], [0.0, 1.0], [1.0, 3.0], [2.0, 5.0], [1.48, 1.83],
              [0.05, 0.5], [0.5, 5], [1.2, 4], [1, 2], [0.2, 0.6], [1.3, 3], [0, 0.9], [0, 3]]
    prob = dict(num_vars=len(names), names=names, bounds=bounds)
    Xs = ssob.sample(prob, 512, calc_second_order=False, seed=3)
    th2 = pd.DataFrame(Xs, columns=names); th2['Nchild'] = 1.084; th2['kv'] = 0.3; th2['kv_sym'] = 0.0
    s2 = simulate(th2, s_micro=s_micro)
    rows = []
    for yname in ['HE_adol', 'atp_adol']:
        Si = asob.analyze(prob, s2[yname].values, calc_second_order=False, seed=3)
        for i, nm in enumerate(names): rows.append(dict(output=yname, parameter=nm, S1=Si['S1'][i], ST=Si['ST'][i], ST_conf=Si['ST_conf'][i]))
    SO = pd.DataFrame(rows); SO.to_csv(os.path.join(R, 'biophysics_sobol.tsv'), sep='\t', index=False)
    print(SO.sort_values(['output', 'ST'], ascending=[True, False]).groupby('output').head(5).round(3).to_string())

if __name__ == '__main__':
    main()
