#!/usr/bin/env python3
"""Step 10. Main and supplementary figures (vector PDF + 600-dpi PNG)."""
import os, sys, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from scipy import stats
from sklearn.metrics import roc_curve
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import biophys as B

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = os.path.join(ROOT, 'results'); F = os.path.join(ROOT, 'figures'); P = os.path.join(ROOT, 'data', 'processed')
os.makedirs(F, exist_ok=True)
plt.rcParams.update({'font.family': 'Liberation Sans', 'font.size': 7, 'axes.titlesize': 7.5, 'axes.labelsize': 7,
                     'xtick.labelsize': 6.5, 'ytick.labelsize': 6.5, 'legend.fontsize': 6.5, 'axes.linewidth': 0.6,
                     'xtick.major.width': 0.6, 'ytick.major.width': 0.6, 'axes.spines.top': False, 'axes.spines.right': False,
                     'pdf.fonttype': 42, 'svg.fonttype': 'none', 'legend.frameon': False})
CE, CK, CM, CA, GR, INK = '#2a78d6', '#eb6834', '#7a7974', '#1baf7a', '#b9b8b2', '#0b0b0b'
CTL, ASD = '#7a7974', '#6250d6'

def tag(ax, s, x=-0.18, y=1.06):
    ax.text(x, y, s, transform=ax.transAxes, fontsize=9, fontweight='bold', va='bottom', ha='left')

def save(fig, name):
    fig.savefig(os.path.join(F, name + '.pdf')); fig.savefig(os.path.join(F, name + '.png'), dpi=600); plt.close(fig)

def box(ax, x, y, w, h, text, fc, ec, fs=6.3, tc=INK):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.008,rounding_size=0.015', fc=fc, ec=ec, lw=0.8))
    ax.text(x + w / 2, y + h / 2, text, ha='center', va='center', fontsize=fs, color=tc, wrap=True)

def arrow(ax, a, b, c=INK, ls='-', lw=0.9):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle='-|>', mutation_scale=7, color=c, lw=lw, ls=ls, shrinkA=1, shrinkB=1))

# ---------------- Figure 1: framework ----------------
def fig1():
    fig = plt.figure(figsize=(7.08, 4.6))
    ax = fig.add_axes([0.0, 0.40, 1.0, 0.60]); ax.set_xlim(0, 1); ax.set_ylim(-0.05, 1); ax.axis('off')
    tag(ax, 'a', 0.005, 0.93)
    box(ax, 0.02, 0.36, 0.17, 0.30, 'Under-pruned circuit\n(mean-field activity map)\n\nspines ×1.66 (adolescence)\n→ activity C ×1.87', '#f1f0ed', CM)
    # channels
    box(ax, 0.27, 0.70, 0.20, 0.22, 'H-E · Ca$^{2+}$ arm\nnuclear Ca$^{2+}$ → CaMK\n→ scaffold phosphorylation φ', '#e7f0fb', CE)
    box(ax, 0.27, 0.42, 0.20, 0.22, 'H-E · energy arm\nATP demand j (Harris 2012)\nvs spare capacity', '#e7f0fb', CE)
    box(ax, 0.27, 0.14, 0.20, 0.22, 'H-K\nintragenic chromatin\n→ Pol II elongation rate v', '#fdeee7', CK)
    box(ax, 0.27, -0.03, 0.20, 0.12, 'H-M (null) · traction → LINC', '#f1f0ed', CM)
    box(ax, 0.55, 0.56, 0.20, 0.30, 'Condensate of the microexon\nactivator (SRRM4–SRSF11–RNPS1)\nlever rule: $c_{sat}\\propto e^{\\gamma(\\phi-\\phi_0)}$\nliquidity $\\propto (ATP/ATP_0)^{\\mu}$', '#e7f0fb', CE)
    box(ax, 0.55, 0.14, 0.20, 0.25, 'Kinetic window\n$PSI = 1-(1-r)\\,e^{-x}$\n$x = k_a L_{down}/v$', '#fdeee7', CK)
    box(ax, 0.82, 0.36, 0.16, 0.30, 'Splicing code\nmicroexon & cassette-exon\ninclusion (ΔPSI)\n\nexon-level signatures\nE-score  vs  K-score', '#f1f0ed', INK)
    for y in [0.81, 0.53, 0.25, 0.03]: arrow(ax, (0.19, 0.51), (0.27, y), CM)
    arrow(ax, (0.47, 0.81), (0.55, 0.74), CE); arrow(ax, (0.47, 0.53), (0.55, 0.64), CE)
    arrow(ax, (0.47, 0.25), (0.55, 0.26), CK); ax.add_patch(FancyArrowPatch((0.47, 0.03), (0.90, 0.36), arrowstyle='-|>', mutation_scale=7, color=CM, lw=0.9, ls=':', connectionstyle='angle,angleA=0,angleB=90,rad=0'))
    arrow(ax, (0.75, 0.71), (0.82, 0.58), CE); arrow(ax, (0.75, 0.26), (0.82, 0.42), CK)
    # b: lever-rule transfer function and emergent ultrasensitivity
    ax2 = fig.add_axes([0.09, 0.07, 0.24, 0.26]); tag(ax2, 'b')
    s = np.linspace(0, 1.6, 400)
    for rho, ls in [(1.5, '-'), (2.6, '--'), (4.0, ':')]:
        I = B.micro_psi(np.maximum(0, s * rho - 1) / (rho - 1), 1, 0.4, 1.5)
        ax2.plot(s, I / B.micro_psi(1, 1, 0.4, 1.5), color=CE, ls=ls, lw=1.2, label=f'ρ₀ = {rho}')
    ax2.plot(s, B.micro_psi(s, 1, 0.4, 1.5) / B.micro_psi(1, 1, 0.4, 1.5), color=GR, lw=1.0, label='no condensate (h₀ = 1.5)')
    ax2.axvline(1, color=GR, lw=0.5, ls='--'); ax2.set_xlabel('scaffold dosage (relative)'); ax2.set_ylabel('microexon inclusion\n(relative)')
    ax2.legend(loc='upper left', fontsize=5.4, handlelength=1.6); ax2.set_ylim(0, 1.6)
    # c: phosphorylation -> dissolution
    ax3 = fig.add_axes([0.40, 0.07, 0.25, 0.26]); tag(ax3, 'c')
    dphi = np.linspace(0, 0.8, 300)
    for g, ls in [(1.0, '-'), (2.7, '--')]:
        S = B.s_eff(0.2 + dphi, 1.0, 2.6, g, 0, 0.2)
        ax3.plot(dphi, B.micro_psi(S, 0.79, 0.4, 1.5) - B.micro_psi(1, 0.79, 0.4, 1.5), color=CE, ls=ls, lw=1.2, label=f'γ = {g}')
    ax3.axvline(np.log(2.6) / 2.7, color=CE, lw=0.5, ls=':'); ax3.text(np.log(2.6) / 2.7 + 0.01, -0.6, 'dissolution\nthreshold', fontsize=5.6, color=CE)
    ax3.set_xlabel('Δφ (phosphorylated fraction)'); ax3.set_ylabel('microexon ΔPSI'); ax3.legend(loc='lower left', fontsize=5.6)
    # d: kinetic window
    ax4 = fig.add_axes([0.73, 0.07, 0.25, 0.26]); tag(ax4, 'd')
    dl = np.linspace(-0.7, 0.7, 200)
    for x, r, ls in [(0.5, 0.2, '-'), (1.5, 0.2, '--'), (3.0, 0.2, ':')]:
        ax4.plot(dl, B.kinetic_dpsi(x, r, dl), color=CK, ls=ls, lw=1.2, label=f'x = {x}')
    ax4.axhline(0, color=GR, lw=0.5); ax4.axvline(0, color=GR, lw=0.5)
    ax4.set_xlabel('Δln v (brake ← → accelerate)'); ax4.set_ylabel('ΔPSI'); ax4.legend(fontsize=5.6)
    save(fig, 'Figure1')

# ---------------- Figure 2: signatures ----------------
def fig2():
    cvE = pd.read_csv(os.path.join(R, 'cv_E.tsv'), sep='\t', index_col=0); cvK = pd.read_csv(os.path.join(R, 'cv_K.tsv'), sep='\t', index_col=0)
    co = pd.read_csv(os.path.join(R, 'signature_coefficients.tsv'), sep='\t', index_col=0)
    sc = pd.read_csv(os.path.join(R, 'exon_scores.tsv'), sep='\t', index_col=0)
    ex = pd.read_csv(os.path.join(R, 'exon_dpsi.tsv'), sep='\t', index_col=0)
    fig, axs = plt.subplots(1, 4, figsize=(7.08, 1.95), gridspec_kw=dict(width_ratios=[1, 1, 1.35, 1]))
    fpr, tpr, _ = roc_curve(cvE.y, cvE.cv_pred); ax = axs[0]
    ax.plot(fpr, tpr, color=CE, lw=1.3); ax.plot([0, 1], [0, 1], color=GR, lw=0.6, ls='--')
    from sklearn.metrics import roc_auc_score
    ax.text(0.45, 0.1, f'AUC = {roc_auc_score(cvE.y, cvE.cv_pred):.2f}\n(gene-grouped CV)', fontsize=6)
    ax.set_xlabel('false-positive rate'); ax.set_ylabel('true-positive rate'); ax.set_title('E-score: Srrm4-KO targets', color=CE, fontsize=6.6, pad=9); tag(ax, 'a', -0.32, 1.2)
    ax = axs[1]
    q = pd.qcut(cvK.cv_pred, 10, labels=False); g = cvK.groupby(q)
    ax.errorbar(g.cv_pred.mean() * 100, g.y.mean() * 100, yerr=g.y.sem() * 100, fmt='o', ms=3.2, color=CK, lw=0.8, capsize=0)
    rho = stats.spearmanr(cvK.cv_pred, cvK.y)
    ax.text(0.04, 0.9, f'ρ = {rho[0]:.2f}, P = {rho[1]:.0e}', transform=ax.transAxes, fontsize=6)
    ax.set_xlabel('predicted ΔPSI (CV, %)'); ax.set_ylabel('observed slow-Pol II ΔPSI\nin motor neurons (%)'); ax.set_title('K-score: slow-Pol II response', color=CK, fontsize=6.6, pad=9); tag(ax, 'b', -0.45, 1.2)
    ax = axs[2]
    lab = {'logL': 'exon length (log)', 'micro': 'microexon (3–27 nt)', 'me3': "3′ss strength", 'me5': "5′ss strength", 'me3_down': "downstream 3′ss",
           'me5_up': "upstream 5′ss", 'logLup': 'upstream intron (log)', 'logLdn': 'downstream intron (log)', 'ugc': 'UGC motifs (−60..−1)',
           'pyr': 'pyrimidine tract', 'gcatg_dn': 'UGCAUG downstream', 'gcatg_up': 'UGCAUG upstream', 'gc_exon': 'exon GC', 'gc_flank': 'flank GC', 'frame': 'frame-preserving'}
    c = co.copy(); c['E'] = c.E_coef / c.E_coef.abs().max(); c['K'] = c.K_coef / c.K_coef.abs().max()
    c = c.loc[c.E.abs().sort_values().index]; y = np.arange(len(c))
    ax.barh(y + 0.2, c.E, height=0.38, color=CE, label='E (logistic)'); ax.barh(y - 0.2, c.K, height=0.38, color=CK, label='K (ridge)')
    ax.set_yticks(y); ax.set_yticklabels([lab[i] for i in c.index], fontsize=5.6); ax.axvline(0, color=INK, lw=0.5)
    ax.set_xlabel('standardized weight (scaled to max)'); ax.legend(loc='lower left', bbox_to_anchor=(0.0, 1.0), ncol=2, fontsize=5.6); tag(ax, 'c', -0.75, 1.1)
    ax = axs[3]
    d = ex.join(sc); d = d[d.dpsi.notna()]
    ax.hexbin(d.E_score, d.K_score * 100, gridsize=35, cmap='Greys', bins='log', mincnt=1, linewidths=0)
    ax.set_xlabel('E-score'); ax.set_ylabel('K-score (ΔPSI %)')
    r = stats.spearmanr(d.E_score, d.K_score)[0]; ax.text(0.40, 0.97, f'ρ = {r:.2f}\nn = {len(d):,}', transform=ax.transAxes, fontsize=6, va='top')
    mi = d.micro == 1; ax.scatter(d.E_score[mi], d.K_score[mi] * 100, s=2, color=CE, lw=0, label='microexons'); ax.legend(loc='lower right', fontsize=5.6, markerscale=3)
    tag(ax, 'd', -0.35, 1.1)
    fig.set_size_inches(7.08, 2.2); fig.tight_layout(w_pad=1.2); save(fig, 'Figure2')

# ---------------- Figure 3: ASD model selection ----------------
def fig3():
    T = pd.read_csv(os.path.join(R, 'T1_model_selection.tsv'), sep='\t'); Rb = pd.read_csv(os.path.join(R, 'T6_robustness.tsv'), sep='\t')
    ex = pd.read_csv(os.path.join(R, 'exon_dpsi.tsv'), sep='\t', index_col=0).join(pd.read_csv(os.path.join(R, 'exon_scores.tsv'), sep='\t', index_col=0))
    mo = pd.read_csv(os.path.join(P, 'mouse_sets_hg19.tsv'), sep='\t', index_col=0); mo.columns = [c.replace('.', '_') for c in mo.columns]
    d = ex.join(mo); d = d[d.dpsi.notna()]
    fig, axs = plt.subplots(1, 4, figsize=(7.08, 2.0), gridspec_kw=dict(width_ratios=[1.05, 1, 1, 1.3]))
    ax = axs[0]
    names = ['M0 nuisance', 'H-K', 'H-E', 'H-E + H-K']; cols = [GR, CK, CE, '#3c3b8f']
    for k, (out, off) in enumerate([('all ages', -0.2), ('10-30 y', 0.2)]):
        t = T[(T.outcome == out) & T.model.isin(names)].set_index('model').loc[names]
        ax.bar(np.arange(4) + off, t.dAIC.values - t.dAIC.min(), width=0.38, color=cols, alpha=1 if k == 0 else 0.55, edgecolor='white', lw=0.5)
    ax.set_xticks(range(4)); ax.set_xticklabels(['nuisance', 'H-K', 'H-E', 'H-E+H-K'], rotation=30, ha='right')
    ax.text(3, 1.5, 'best', ha='center', fontsize=5.8, color='#3c3b8f')
    ax.set_ylabel('ΔAIC (vs best)'); ax.text(0.35, 0.92, 'solid: all ages\nlight: 10–30 y', transform=ax.transAxes, fontsize=5.8); tag(ax, 'a', -0.3)
    for ax, col, lab, c in [(axs[1], 'E_score', 'E-score decile', CE), (axs[2], 'K_score', 'K-score decile', CK)]:
        q = pd.qcut(d[col], 10, labels=False); w = 1 / d.se ** 2
        m = d.assign(w=w, q=q).groupby('q').apply(lambda g: pd.Series({'m': np.average(g.dpsi, weights=g.w), 's': 1 / np.sqrt(g.w.sum())}), include_groups=False)
        ax.errorbar(m.index + 1, m.m * 100, yerr=1.96 * m.s * 100, fmt='o-', color=c, ms=3, lw=0.9, capsize=0)
        ax.axhline(0, color=GR, lw=0.5); ax.set_xlabel(lab); ax.set_ylabel('ASD ΔPSI (%)'); ax.set_xticks([1, 5, 10])
    tag(axs[1], 'b', -0.3); tag(axs[2], 'c', -0.3)
    ax = axs[3]
    y = np.arange(len(Rb))[::-1]
    lab = ['cortex (main)', 'locus-clustered SE', 'no composition adj.', 'cortex 10–30 y', 'microexons excluded', 'exons ≥ 51 nt', 'cerebellum (replication)']
    # z-scores of the joint-model coefficients
    zE = stats.norm.isf(Rb.p_E.clip(1e-300) / 2) * np.sign(Rb.b_E); zK = stats.norm.isf(Rb.p_K.clip(1e-300) / 2) * np.sign(Rb.b_K)
    ax.scatter(zE, y + 0.12, color=CE, s=12, label='H-E (scaffold)', zorder=3); ax.scatter(zK, y - 0.12, color=CK, s=12, label='H-K (elongation)', zorder=3)
    for yy, a, b in zip(y, zE, zK): ax.plot([0, a], [yy + 0.12] * 2, color=CE, lw=0.8); ax.plot([0, b], [yy - 0.12] * 2, color=CK, lw=0.8)
    ax.axvline(0, color=INK, lw=0.5); ax.axvline(1.96, color=GR, lw=0.5, ls='--'); ax.axvline(-1.96, color=GR, lw=0.5, ls='--')
    ax.set_yticks(y); ax.set_yticklabels(lab, fontsize=5.8); ax.set_xlabel('signed z (joint model)'); ax.legend(loc='lower left', bbox_to_anchor=(-0.05, 1.0), ncol=2, fontsize=5.6, handletextpad=0.2, columnspacing=0.8)
    tag(ax, 'd', -0.6)
    fig.tight_layout(w_pad=0.9); save(fig, 'Figure3')

# ---------------- Figure 4: donor level ----------------
def fig4():
    D = pd.read_csv(os.path.join(R, 'donor_indices.tsv'), sep='\t', index_col=0); T5 = pd.read_csv(os.path.join(R, 'T5_donor_tests.tsv'), sep='\t').set_index('index')
    obs = pd.read_csv(os.path.join(R, 'biophysics_observed_age.tsv'), sep='\t')
    fig, axs = plt.subplots(1, 4, figsize=(7.08, 1.95))
    asd = D['ASD.CTL'] == 'ASD'
    ax = axs[0]; rng = np.random.default_rng(1)
    for k, (ix, lab, c) in enumerate([('scaffold_index', 'scaffold\n(top-E exons)', CE), ('elong_index', 'elongation\n(top-|K| exons)', CK)]):
        for j, (m, cc) in enumerate([(~asd, CTL), (asd, c)]):
            x = 2 * k + j * 0.8 + rng.uniform(-0.15, 0.15, m.sum())
            ax.scatter(x, D.loc[m, ix], s=5, color=cc, lw=0, alpha=0.85)
            ax.plot([2 * k + j * 0.8 - 0.25, 2 * k + j * 0.8 + 0.25], [D.loc[m, ix].mean()] * 2, color=INK, lw=1)
        ax.text(2 * k + 0.4, 0.29, f"P = {T5.loc[ix, 'p']:.3f}", ha='center', fontsize=5.8)
    ax.set_xticks([0, 0.8, 2, 2.8]); ax.set_xticklabels(['CTL', 'ASD', 'CTL', 'ASD']); ax.set_ylabel('donor index (residual z)')
    ax.text(0.4, -0.38, 'scaffold', ha='center', fontsize=6, color=CE); ax.text(2.4, -0.38, 'elongation', ha='center', fontsize=6, color=CK)
    ax.set_ylim(-0.42, 0.36); tag(ax, 'a', -0.3)
    ax = axs[1]
    x = D.loc[asd, 'scaffold_index']; c = D.loc[~asd, 'scaffold_index']
    bins = np.linspace(-0.35, 0.2, 23)
    ax.hist(c, bins=bins, color=CTL, alpha=0.45, density=True, label='CTL'); ax.hist(x, bins=bins, color=CE, alpha=0.6, density=True, label='ASD')
    ax.set_xlim(-0.36, 0.22); xx = np.linspace(-0.36, 0.22, 300); pi = T5.loc['scaffold_index', 'mix_pi']; dl = T5.loc['scaffold_index', 'mix_delta']
    ax.plot(xx, stats.norm.pdf(xx, c.mean(), c.std()), color=CTL, lw=1)
    ax.text(0.03, 0.93, f"subgroup π = {pi:.2f}\nLRT = {T5.loc['scaffold_index','mix_LRT']:.1f}, P = {T5.loc['scaffold_index','mix_p']:.3f}\nskew = {T5.loc['scaffold_index','skew_asd']:.2f}", transform=ax.transAxes, fontsize=5.6, va='top')
    ax.set_xlabel('scaffold index'); ax.set_ylabel('density'); ax.legend(loc='center left', fontsize=5.6); tag(ax, 'b', -0.3)
    ax = axs[2]
    for m, cc, lab in [(~asd, CTL, 'CTL'), (asd, ASD, 'ASD')]:
        z = (D.loc[m, 'ieg'] - D.loc[m, 'ieg'].mean()) / D.loc[m, 'ieg'].std()
        ax.scatter(z, D.loc[m, 'micro_index'], s=6, color=cc, lw=0, label=lab)
        b = np.polyfit(z, D.loc[m, 'micro_index'], 1); xs = np.linspace(-2.5, 2.5, 10); ax.plot(xs, np.polyval(b, xs), color=cc, lw=1)
    ax.text(0.03, 0.04, f"β(ASD) = {T5.loc['micro_index','beta_ieg_ASD']:.2f}, P = {T5.loc['micro_index','p_ieg_ASD']:.3f}\nβ(CTL) = {T5.loc['micro_index','beta_ieg_CTL']:.2f}, P = {T5.loc['micro_index','p_ieg_CTL']:.3f}", transform=ax.transAxes, fontsize=5.6)
    ax.set_xlabel('activity index (IEG, z)'); ax.set_ylabel('microexon index'); ax.legend(loc='upper right', fontsize=5.6); tag(ax, 'c', -0.3)
    ax = axs[3]
    ax.errorbar(range(3), obs.dpsi * 100, yerr=1.96 * obs.se * 100, fmt='o', color=CE, ms=4, capsize=0, lw=1)
    for k, r in obs.iterrows(): ax.text(k, r.dpsi * 100 + 1.96 * r.se * 100 + 0.3, f'P = {r.p:.3f}' if r.p >= 0.001 else f'P = {r.p:.0e}', ha='center', fontsize=5.6)
    ax.axhline(0, color=GR, lw=0.5); ax.set_xticks(range(3)); ax.set_xticklabels(obs.band); ax.set_ylabel('microexon ΔPSI (%)'); ax.set_xlim(-0.5, 2.5)
    tag(ax, 'd', -0.3)
    fig.tight_layout(w_pad=0.9); save(fig, 'Figure4')

# ---------------- Figure 5: biophysics ----------------
def fig5():
    dr = pd.read_csv(os.path.join(R, 'biophysics_draws.tsv.gz'), sep='\t'); H = pd.read_csv(os.path.join(R, 'biophysics_emergent_hill.tsv'), sep='\t')
    obs = pd.read_csv(os.path.join(R, 'biophysics_observed_age.tsv'), sep='\t'); scan = pd.read_csv(os.path.join(R, 'biophysics_subgroup_scan.tsv'), sep='\t')
    SO = pd.read_csv(os.path.join(R, 'biophysics_sobol.tsv'), sep='\t'); PQ = pd.read_csv(os.path.join(R, 'biophysics_abc_posterior.tsv'), sep='\t')
    fig, axs = plt.subplots(2, 3, figsize=(7.08, 3.9))
    ax = axs[0, 0]
    ax.hist(dr.j_adol, bins=60, color=CE, alpha=0.7, density=True, label='ATP demand j (adolescent ASD)')
    ax.hist(dr.SRC, bins=30, color=GR, alpha=0.6, density=True, label='spare respiratory capacity')
    ax.set_xlabel('relative ATP flux'); ax.set_ylabel('density'); ax.legend(fontsize=5.6, loc='upper right')
    ax.text(0.45, 0.55, f'demand > capacity in\n{(dr.j_adol >= dr.SRC).mean() * 100:.0f}% of draws', transform=ax.transAxes, fontsize=6); tag(ax, 'a')
    ax = axs[0, 1]
    ax.hist(H.h_eff.clip(upper=20), bins=40, color=CE, alpha=0.8, density=True)
    CAL = pd.read_csv(os.path.join(R, 'transfer_calibration.tsv'), sep='\t', index_col=0).iloc[:, 0]
    ax.axvspan(CAL.h_lo, CAL.h_hi, color=CA, alpha=0.15, lw=0); ax.axvline(CAL.h_med, color=CA, lw=1, ls='--')
    ax.text(CAL.h_med + 0.3, ax.get_ylim()[1] * 0.85, f'calibrated on human cortex\nh = {CAL.h_med:.1f} ({CAL.h_lo:.1f}–{CAL.h_hi:.1f})', fontsize=5.8, color='#0d6e4b')
    ax.set_xlabel('emergent Hill coefficient h_eff'); ax.set_ylabel('density'); tag(ax, 'b')
    ax = axs[0, 2]
    chans = [('HE_ca_adol', 'H-E Ca$^{2+}$', CE), ('HE_atp_adol', 'H-E ATP', '#8fb8ea'), ('HK_adol', 'H-K (accelerate)', CK), ('HKsym_adol', 'H-K (either sign)', '#f3a888')]
    data = [dr[c].clip(-0.8, 0.1) * 100 for c, _, _ in chans]
    vp = ax.violinplot(data, showextrema=False, widths=0.8)
    for b_, (_, _, c) in zip(vp['bodies'], chans): b_.set_facecolor(c); b_.set_alpha(0.7); b_.set_edgecolor('none')
    oa = obs.loc[obs.band == '10-30 y']; ax.axhspan((oa.dpsi - 2 * oa.se).values[0] * 100, (oa.dpsi + 2 * oa.se).values[0] * 100, color=INK, alpha=0.12, lw=0)
    ax.axhline(0, color=GR, lw=0.5); ax.set_xticks(range(1, 5)); ax.set_xticklabels([l for _, l, _ in chans], rotation=25, ha='right', fontsize=5.8)
    ax.set_ylabel('prior-predictive adolescent\nmicroexon ΔPSI (%)'); ax.set_ylim(-80, 8); ax.text(2.6, -72, 'grey band: observed\n±2 s.e. (10–30 y)', fontsize=5.4); tag(ax, 'c')
    ax = axs[1, 0]
    hk = dr.kv_sym; acc_mask = None
    p = PQ[(PQ.channel == 'HKsym') & (PQ.parameter == 'kv_sym')].iloc[0]
    ax.hist(dr.kv_sym, bins=40, color=GR, alpha=0.5, density=True, label='prior')
    xs = np.linspace(-0.7, 0.7, 200)
    # approximate posterior by accepted draws (recomputed)
    oc, sc_ = obs.loc[obs.band == '<=10 y', ['dpsi', 'se']].values[0]; oa_, sa = obs.loc[obs.band == '10-30 y', ['dpsi', 'se']].values[0]
    acc = ((dr.HKsym_child - oc) / sc_) ** 2 + ((dr.HKsym_adol - oa_) / sa) ** 2 <= 4
    ax.hist(dr.kv_sym[acc], bins=40, color=CK, alpha=0.75, density=True, label='posterior (ABC)')
    ax.axvline(0, color=INK, lw=0.5); ax.annotate('', xy=(0.65, 3.2), xytext=(0.15, 3.2), arrowprops=dict(arrowstyle='->', color=CA, lw=1))
    ax.text(0.12, 3.35, 'depolarization →\nacceleration (literature)', fontsize=5.4, color='#0d6e4b')
    ax.set_xlabel('κ_v (max Δln v under full CaMK activation)'); ax.set_ylabel('density'); ax.legend(fontsize=5.6, loc='upper left'); ax.set_ylim(0, 4.3); tag(ax, 'd')
    ax = axs[1, 1]
    ax.errorbar(scan.sd_log2, scan.frac_median * 100, yerr=[(scan.frac_median - scan.frac_q05) * 100, (scan.frac_q95 - scan.frac_median) * 100], fmt='o-', color=CE, ms=3, lw=0.9, capsize=0)
    ax.axhspan(28, 30, color=CA, alpha=0.25, lw=0); ax.text(1.05, 17, 'observed subgroup\n(28–30%)', fontsize=5.6, color='#0d6e4b')
    ax.axvline(scan.sd_log2.iloc[0], color=GR, lw=0.6, ls='--'); ax.text(scan.sd_log2.iloc[0] + 0.03, 40, 'SRRM4 mRNA\ns.d. (donors)', fontsize=5.4)
    ax.set_xlabel('inter-individual s.d. of scaffold\nsupersaturation (log₂ units)'); ax.set_ylabel('predicted donors crossing\ndissolution threshold (%)'); tag(ax, 'e')
    ax = axs[1, 2]
    s = SO[SO.output == 'HE_adol'].sort_values('ST', ascending=True).tail(8)
    ax.barh(range(len(s)), s.ST, color=CE, alpha=0.85, label='total (S_T)'); ax.barh(range(len(s)), s.S1, color='#0f4b8f', height=0.4, label='first order (S₁)')
    SYM = {'gamma': 'γ', 'phi0': 'φ₀', 'rho0': 'ρ₀', 'chronic': 'adaptation', 'KC': 'K_C', 'SRC': 'SRC', 'q': 'q', 'n': 'n', 'mu': 'μ', 'Nadol': 'spine ratio', 'kappa': 'κ', 'h0': 'h₀', 'K0': 'K₀', 'Cb': 'C_b', 'eta': 'η'}
    ax.set_yticks(range(len(s))); ax.set_yticklabels([SYM.get(x, x) for x in s.parameter]); ax.set_xlabel('Sobol index (adolescent H-E ΔPSI)'); ax.legend(fontsize=5.6, loc='lower right'); tag(ax, 'f')
    fig.tight_layout(h_pad=1.3, w_pad=1.0); save(fig, 'Figure5')

# ---------------- Figure 6: mechanical null + integrated verdict ----------------
def fig6():
    md = pd.read_csv(os.path.join(R, 'biophysics_mechanical_draws.tsv.gz'), sep='\t'); L = pd.read_csv(os.path.join(R, 'T7_lad.tsv'), sep='\t').iloc[0]
    fig = plt.figure(figsize=(7.08, 2.2))
    ax = fig.add_axes([0.07, 0.2, 0.25, 0.68])
    ax.hist(np.log10(md.ratio).clip(lower=-10), bins=np.linspace(-10, 0, 51), color=CM, alpha=0.8)
    for v, l, dx in [(-2, '1%', -0.75), (np.log10(0.05), '5%', 0.1)]: ax.axvline(v, color=INK, lw=0.6, ls='--'); ax.text(v + dx, ax.get_ylim()[1] * 0.92, l, fontsize=5.8)
    ax.set_xlabel('log₁₀ (ΔF_nucleus / F_basal)  [≤ −10 pooled]'); ax.set_ylabel('Monte Carlo draws'); tag(ax, 'a')
    ax.text(0.02, 0.62, f'median {np.median(md.ratio) * 100:.2f}%\n{(md.ratio < 0.05).mean() * 100:.0f}% of draws < 5%', transform=ax.transAxes, fontsize=5.8)
    ax = fig.add_axes([0.40, 0.2, 0.17, 0.68])
    ex = pd.read_csv(os.path.join(R, 'exon_dpsi.tsv'), sep='\t', index_col=0)
    ax.bar([0, 1], [L.mean_dpsi_nonlad * 100, L.mean_dpsi_lad * 100], color=[GR, CM], width=0.6)
    sem = [ex.dpsi.std() / np.sqrt(L.n_nonlad) * 100, ex.dpsi.std() / np.sqrt(L.n_lad) * 100]
    ax.errorbar([0, 1], [L.mean_dpsi_nonlad * 100, L.mean_dpsi_lad * 100], yerr=[1.96 * x for x in sem], fmt='none', color=INK, lw=0.8)
    ax.set_xticks([0, 1]); ax.set_xticklabels(['non-LAD', 'LAD']); ax.set_ylabel('mean ASD ΔPSI (%)'); ax.axhline(0, color=INK, lw=0.5)
    ax.text(0.5, 0.9, f"adjusted P = {L.p_lad:.2f}", transform=ax.transAxes, ha='center', fontsize=5.8); tag(ax, 'b', -0.45)
    ax = fig.add_axes([0.62, 0.02, 0.37, 0.92]); ax.axis('off'); ax.set_xlim(0, 1); ax.set_ylim(0, 1); tag(ax, 'c', 0.0, 0.93)
    rows = [('Channel', 'Exon\nspecificity', 'Donor\nswitch', 'Activity\ncoupling', 'Physical\nplausibility', INK, '#ffffff'),
            ('H-E Ca$^{2+}$ →\ncondensate', 'dominant\n(ΔAIC 67)', 'yes\n(π≈0.29)', 'yes (IEG)', 'h_eff ≈ 5', CE, '#e7f0fb'),
            ('H-E ATP', 'not specific', '—', 'no\n(OXPHOS)', 'demand > SRC\nin 46%', '#5f8fc9', '#eef4fb'),
            ('H-K elongation', 'secondary\n(ΔAIC 28)', 'no', 'no', 'needs a brake\n(≈12% slower)', CK, '#fdeee7'),
            ('H-M mechanics', 'none (LAD)', '—', '—', '≈0.04% load', CM, '#f1f0ed')]
    xs = [0.01, 0.22, 0.41, 0.58, 0.77]; ws = [0.20, 0.18, 0.16, 0.18, 0.21]
    for i, r in enumerate(rows):
        y = 0.86 - i * 0.19
        for j in range(5):
            ax.add_patch(FancyBboxPatch((xs[j], y - 0.08), ws[j], 0.16, boxstyle='round,pad=0.004,rounding_size=0.01', fc=r[6] if i else '#ffffff', ec=r[5] if j == 0 and i else '#dddcd6', lw=0.6))
            ax.text(xs[j] + ws[j] / 2, y, r[j], ha='center', va='center', fontsize=5.0, fontweight='bold' if i == 0 or j == 0 else 'normal', color=r[5] if j == 0 else INK)
    save(fig, 'Figure6')

# ---------------- Supplementary figures ----------------
def figS():
    # S1: age-band model selection & ICC; S2: KCl; S3: Sobol ATP
    T3 = pd.read_csv(os.path.join(R, 'T3_icc.tsv'), sep='\t'); T4 = pd.read_csv(os.path.join(R, 'T4_kcl.tsv'), sep='\t')
    SO = pd.read_csv(os.path.join(R, 'biophysics_sobol.tsv'), sep='\t'); H = pd.read_csv(os.path.join(R, 'biophysics_emergent_hill.tsv'), sep='\t')
    fig, axs = plt.subplots(1, 4, figsize=(7.08, 1.9))
    ax = axs[0]; t = T3.iloc[:4]
    ax.bar(range(4), t.ICC, color=[GR, GR, CK, '#f3a888'], width=0.6)
    ax.errorbar([0, 1], t.null_mean[:2], yerr=2 * t.null_sd[:2], fmt='o', color=INK, ms=2.5, lw=0.8, label='permutation null (±2 s.d.)'); ax.legend(fontsize=5.4, loc='lower right')
    ax.set_xticks(range(4)); ax.set_xticklabels(['raw', 'resid.', 'high |K|', 'low |K|'], rotation=25, ha='right'); ax.set_ylabel('within-locus ICC of ASD ΔPSI'); tag(ax, 'a', -0.3)
    ax = axs[1]; t = T4.iloc[:3]
    ax.bar(range(3), t.AIC - t.AIC.min(), color=[CE, CK, '#3c3b8f'], width=0.6); ax.set_xticks(range(3)); ax.set_xticklabels(['E', 'K', 'E+K'])
    ax.set_ylabel('ΔAIC (KCl-responsive exons)'); tag(ax, 'b', -0.3)
    ax = axs[2]; s = SO[SO.output == 'atp_adol'].sort_values('ST').tail(8)
    ax.barh(range(len(s)), s.ST, color='#8fb8ea', label='S_T'); ax.barh(range(len(s)), s.S1, color='#0f4b8f', height=0.4, label='S₁')
    ax.set_yticks(range(len(s))); ax.set_yticklabels([{'chronic': 'adaptation', 'Nadol': 'spine ratio', 'kappa': 'κ', 'eta': 'η', 'KC': 'K_C', 'Cb': 'C_b'}.get(x, x) for x in s.parameter]); ax.set_xlabel('Sobol index (adolescent ATP ratio)'); ax.legend(fontsize=5.6); tag(ax, 'c', -0.3)
    ax = axs[3]; ax.scatter(H.rho0, H.h_eff.clip(upper=20), s=2, c=H.h0, cmap='Blues', lw=0)
    ax.set_xlabel('baseline supersaturation ρ₀'); ax.set_ylabel('h_eff'); tag(ax, 'd', -0.3)
    fig.tight_layout(w_pad=1.0); save(fig, 'FigureS1')

def figS2():
    """Supplementary Fig. 2: the microexon deficit is post-transcriptional, switch-like and ultrasensitive."""
    SF = pd.read_csv(os.path.join(R, 'sf_expression.tsv'), sep='\t'); D = pd.read_csv(os.path.join(R, 'donor_microexon_psi.tsv'), sep='\t', index_col=0)
    CAL = pd.read_csv(os.path.join(R, 'transfer_calibration.tsv'), sep='\t', index_col=0).iloc[:, 0]
    PO = pd.read_csv(os.path.join(R, 'transfer_posterior.tsv.gz'), sep='\t')
    fig, axs = plt.subplots(1, 4, figsize=(7.08, 1.95), gridspec_kw=dict(width_ratios=[1.25, 1, 1, 1]))
    ax = axs[0]; genes = ['SRRM4', 'SRRM3', 'RBFOX1', 'SRSF11', 'RNPS1', 'CPEB4']
    for k, (mdl, c, off) in enumerate([('bulk', GR, -0.18), ('per-cell-type (composition-adjusted)', CE, 0.18)]):
        t = SF[(SF.model == mdl) & SF.gene.isin(genes)].set_index('gene').loc[genes]
        ax.errorbar(np.arange(len(genes)) + off, t.log2FC, yerr=1.96 * t.se, fmt='o', color=c, ms=3, lw=0.8, capsize=0, label='bulk' if k == 0 else 'composition-adjusted')
    ax.axhline(0, color=INK, lw=0.5); ax.set_xticks(range(len(genes))); ax.set_xticklabels(genes, rotation=35, ha='right', fontsize=5.8)
    ax.set_ylabel('ASD log₂FC (±95% CI)'); ax.legend(fontsize=5.4, loc='lower left'); tag(ax, 'a', -0.32, 1.08)
    ax = axs[1]; c, a = D[D.asd == 0].psi, D[D.asd == 1].psi
    bins = np.linspace(min(D.psi) - 0.005, max(D.psi) + 0.005, 18)
    ax.hist(c, bins=bins, color=CTL, alpha=0.45, density=True, label='CTL'); ax.hist(a, bins=bins, color=CE, alpha=0.6, density=True, label='ASD')
    xx = np.linspace(bins[0], bins[-1], 300); ax.plot(xx, stats.norm.pdf(xx, c.mean(), c.std()), color=CTL, lw=1)
    ax.text(0.03, 0.95, f"π = {CAL.pi:.2f}\nδ = {CAL.delta:.3f}\n({CAL.delta_lo:.3f}, {CAL.delta_hi:.3f})", transform=ax.transAxes, fontsize=5.6, va='top')
    ax.set_xlabel('neural-microexon PSI (donor)'); ax.set_ylabel('density'); ax.legend(fontsize=5.4, loc='upper right'); tag(ax, 'b', -0.3)
    ax = axs[2]
    for g, cc, lab in [(0, CTL, 'CTL'), (1, ASD, 'ASD')]:
        x = D[D.asd == g]; ax.scatter(x.srrm_res, x.psi, s=6, color=cc, lw=0, label=lab)
        b = np.polyfit(x.srrm_res, x.psi, 1); xs = np.linspace(D.srrm_res.min(), D.srrm_res.max(), 10); ax.plot(xs, np.polyval(b, xs), color=cc, lw=1)
    ax.text(0.03, 0.04, f"slope CTL {CAL.slope_ctl:.3f} (P = {CAL.slope_ctl_p:.2f})\nslope ASD {CAL.slope_asd:.3f} (P = {CAL.slope_asd_p:.2f})", transform=ax.transAxes, fontsize=5.4)
    ax.set_xlabel('per-neuron SRRM4/SRRM3 (log₂, residual)'); ax.set_ylabel('neural-microexon PSI'); ax.legend(fontsize=5.4, loc='upper left'); tag(ax, 'c', -0.3)
    ax = axs[3]
    ax.hist(PO.h, bins=30, color=CA, alpha=0.8, density=True)
    ax.axvline(CAL.h_med, color=INK, lw=0.8, ls='--'); ax.set_xlabel('Hill coefficient h (posterior)'); ax.set_ylabel('density')
    ax.text(0.58, 0.97, f"h = {CAL.h_med:.1f}\n({CAL.h_lo:.1f}–{CAL.h_hi:.1f})\nK = {CAL.K_med:.2f}", transform=ax.transAxes, fontsize=5.6, va='top'); tag(ax, 'd', -0.3)
    fig.tight_layout(w_pad=1.0); save(fig, 'FigureS2')

if __name__ == '__main__':
    fig1(); fig2(); fig3(); fig4(); fig5(); fig6(); figS(); figS2()
    print('figures written to', F)
