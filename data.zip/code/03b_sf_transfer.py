#!/usr/bin/env python3
"""Step 3b. Characterizing the microexon deficit in this cohort: is it transcriptional, graded or switch-like?

(a) Splicing-factor transcripts per neuron: bulk cortical RNA-seq (Gandal et al. 2022; 725 samples, 11 regions,
    dup15q excluded) modelled with and without cell-type composition, donor-clustered SE.
(b) Donor-level neural-microexon inclusion in PSI units (Parikshak et al. 2016, composition-adjusted) and a
    two-component mixture with one component fixed at the control distribution (donor bootstrap CI).
(c) Within-group dose-response of inclusion on per-neuron SRRM4/SRRM3 expression.
(d) Bayesian grid calibration of the scaffold-to-inclusion transfer function I(S) = Imax S^h / (K^h + S^h) on
    (b) and (c); used as the empirical benchmark of the condensate model.
Outputs: results/sf_expression.tsv, results/transfer_calibration.tsv, results/transfer_posterior.tsv.gz
"""
import os, sys, numpy as np, pandas as pd, statsmodels.api as sm
from scipy import stats
from scipy.optimize import minimize
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
d3 = __import__('03_asd_dpsi')

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'data', 'processed'); R = os.path.join(ROOT, 'results')
rng = np.random.default_rng(314)
MARK = list(d3.MARKERS)
GENES = ['SRRM4', 'SRRM3', 'RBFOX1', 'SRSF11', 'RNPS1', 'CPEB4', 'NOVA2', 'PTBP2']

def sf_expression():
    E = pd.read_parquet(os.path.join(P, 'gandal_expr.parquet')); m = pd.read_csv(os.path.join(P, 'gandal_meta.tsv'), sep='\t', index_col=0)
    E.index = d3.gene_symbols(E.index); E = E.groupby(level=0).mean()
    keep = m.Diagnosis != 'Dup15q'; m, E = m[keep], E.loc[:, keep.values]
    sc = pd.DataFrame({k: d3.zscore_score(E, g)[0] for k, g in d3.MARKERS.items()})
    X0 = pd.DataFrame({'asd': (m.Diagnosis == 'ASD') * 1.0, 'age': m.Age.astype(float), 'male': (m.Sex.astype(str) == 'M') * 1.0,
                       'pmi': m.PMI.astype(float).fillna(m.PMI.astype(float).median()), 'rin': m.RIN.astype(float).fillna(m.RIN.astype(float).median())}, index=m.index)
    for c in ['region', 'seq_batch', 'Brain_Bank_Source']:
        X0 = X0.join(pd.get_dummies(m[c].astype(str), prefix=c, drop_first=True).astype(float))
    X0 = sm.add_constant(X0); X1 = X0.join(sc)
    g = m.subject.astype(str).values
    rows = []
    for gene in GENES + ['__neuron__', '__astro__']:
        y = sc['neuron'] if gene == '__neuron__' else sc['astro'] if gene == '__astro__' else E.loc[gene]
        for lab, X in [('bulk', X0), ('per-cell-type (composition-adjusted)', X1 if not gene.startswith('__') else X0)]:
            f = sm.OLS(y.values, X.values).fit(cov_type='cluster', cov_kwds={'groups': g})
            i = list(X.columns).index('asd'); G = len(np.unique(g))
            t = f.params[i] / f.bse[i]
            rows.append(dict(gene=gene.strip('_'), model=lab, log2FC=f.params[i], se=f.bse[i], p=2 * stats.t.sf(abs(t), G - 1), samples=len(y), donors=G))
    T = pd.DataFrame(rows); print(T.round(4).to_string())
    T.to_csv(os.path.join(R, 'sf_expression.tsv'), sep='\t', index=False)
    return E, m, sc

def donor_microexon():
    psi = pd.read_parquet(os.path.join(P, 'psi_ctx.parquet'))
    meta = pd.read_csv(os.path.join(P, 'meta_ctx.tsv'), sep='\t', index_col=0); meta.index = psi.columns
    cov = pd.read_csv(os.path.join(P, 'sample_covariates.tsv'), sep='\t', index_col=0).reindex(psi.columns)
    ex = pd.read_csv(os.path.join(R, 'exon_dpsi.tsv'), sep='\t', index_col=0)
    keep = (meta['Detailed.Diagnosis'] != 'Chromosome 15q Duplication Syndrome') & cov.neuron.notna()
    meta, cov, psi = meta[keep], cov[keep], psi.loc[:, keep.values]
    mic = ex[(ex.micro == 1) & (ex.psi_ctl > 0.5)].index
    y = psi.loc[mic].mean(0)
    X = pd.DataFrame({'asd': (meta['ASD.CTL'] == 'ASD') * 1.0, 'age': meta.Age, 'ba9': (meta.RegionID == 'ba9') * 1.0, 'rin': meta.RIN}, index=meta.index).join(cov[MARK])
    f = sm.OLS(y, sm.add_constant(X)).fit()
    adj = y - (X.drop(columns='asd') - X.drop(columns='asd').mean()) @ f.params.drop(['const', 'asd'])   # covariate-adjusted, diagnosis retained
    D = pd.DataFrame({'psi': adj, 'donor': meta.BrainID, 'asd': X.asd, 'age': meta.Age,
                      'srrm': (cov.g_SRRM4 + cov.g_SRRM3) / 2, 'neuron': cov.neuron, 'ba9': X.ba9}).groupby('donor').mean()
    # per-neuron SRRM4/SRRM3 (residual on neuronal content, age and region)
    r = sm.OLS(D.srrm, sm.add_constant(D[['neuron', 'age', 'ba9']])).fit().resid; D['srrm_res'] = r
    return D, len(mic)

def mixture(x, mu, sd):
    def nll(t):
        pi = 1 / (1 + np.exp(-t[0])); L = (1 - pi) * stats.norm.pdf(x, mu, sd) + pi * stats.norm.pdf(x, mu + t[1], np.exp(t[2]))
        return -np.sum(np.log(L + 1e-300))
    best = min((minimize(nll, [0, d0, np.log(sd)], method='Nelder-Mead', options=dict(maxiter=5000)) for d0 in [-0.15, -0.08, -0.04, 0.04]), key=lambda r: r.fun)
    pi = 1 / (1 + np.exp(-best.x[0])); return pi, best.x[1], best.fun, -np.sum(stats.norm.logpdf(x, mu, sd))

def main():
    sf_expression()
    D, nmic = donor_microexon()
    c, a = D[D.asd == 0], D[D.asd == 1]
    mu, sd = c.psi.mean(), c.psi.std()
    pi, delta, nll1, nll0 = mixture(a.psi.values, mu, sd)
    boot = []
    for _ in range(400):
        cb = c.sample(len(c), replace=True, random_state=int(rng.integers(1e9))); ab = a.sample(len(a), replace=True, random_state=int(rng.integers(1e9)))
        p_, d_, *_ = mixture(ab.psi.values, cb.psi.mean(), cb.psi.std()); boot.append((p_, d_))
    boot = np.array(boot)
    sl = {}
    for lab, g in [('CTL', c), ('ASD', a)]:
        f = sm.OLS(g.psi, sm.add_constant(g[['srrm_res', 'age']])).fit(); sl[lab] = (f.params['srrm_res'], f.bse['srrm_res'], f.pvalues['srrm_res'])
    print(f'neural microexons: {nmic}; control PSI {mu:.3f} (sd {sd:.3f}); mixture pi={pi:.3f} delta={delta:.4f} LRT={2*(nll0-nll1):.2f}')
    print('bootstrap 95% CI pi', np.percentile(boot[:, 0], [2.5, 97.5]), 'delta', np.percentile(boot[:, 1], [2.5, 97.5]))
    print('dose-response slopes (PSI per log2 unit):', sl)
    # grid posterior over (h, K, phi_d); Imax fixed by the control set point I(1) = mu
    hs = np.linspace(1, 15, 141); Ks = np.linspace(0.05, 0.95, 91); ph = np.linspace(0.02, 1.0, 99)
    H, Kk, Ph = np.meshgrid(hs, Ks, ph, indexing='ij')
    Imax = mu * (Kk ** H + 1)
    I = lambda S: Imax * S ** H / (Kk ** H + S ** H)
    slope = lambda S: np.log(2) * Imax * H * Kk ** H * S ** H / (Kk ** H + S ** H) ** 2
    d_se = (np.percentile(boot[:, 1], 97.5) - np.percentile(boot[:, 1], 2.5)) / 3.92
    LL = (stats.norm.logpdf(I(Ph) - mu, delta, d_se) + stats.norm.logpdf(slope(1.0), sl['CTL'][0], sl['CTL'][1])
          + stats.norm.logpdf(pi * slope(Ph) + (1 - pi) * slope(1.0), sl['ASD'][0], sl['ASD'][1]))
    LL[Imax > 1] = -np.inf
    w = np.exp(LL - LL[np.isfinite(LL)].max()); w /= w.sum()
    def q(Z, p): o = np.argsort(Z.ravel()); cw = np.cumsum(w.ravel()[o]); return Z.ravel()[o][np.searchsorted(cw, p)]
    out = dict(n_neural_microexons=nmic, n_ctl_donors=len(c), n_asd_donors=len(a), ctl_psi=mu, ctl_sd=sd, pi=pi, pi_lo=np.percentile(boot[:, 0], 2.5),
               pi_hi=np.percentile(boot[:, 0], 97.5), delta=delta, delta_lo=np.percentile(boot[:, 1], 2.5), delta_hi=np.percentile(boot[:, 1], 97.5),
               LRT=2 * (nll0 - nll1), levene_p=stats.levene(a.psi, c.psi).pvalue,
               slope_ctl=sl['CTL'][0], slope_ctl_se=sl['CTL'][1], slope_ctl_p=sl['CTL'][2], slope_asd=sl['ASD'][0], slope_asd_se=sl['ASD'][1], slope_asd_p=sl['ASD'][2],
               h_med=q(H, .5), h_lo=q(H, .025), h_hi=q(H, .975), K_med=q(Kk, .5), K_lo=q(Kk, .025), K_hi=q(Kk, .975), phi_med=q(Ph, .5), phi_lo=q(Ph, .025), phi_hi=q(Ph, .975))
    pd.Series(out).to_csv(os.path.join(R, 'transfer_calibration.tsv'), sep='\t'); print(pd.Series(out).round(4))
    idx = rng.choice(w.size, 4000, p=w.ravel())
    pd.DataFrame({'h': H.ravel()[idx], 'K': Kk.ravel()[idx], 'phi_d': Ph.ravel()[idx]}).to_csv(os.path.join(R, 'transfer_posterior.tsv.gz'), sep='\t', index=False, compression='gzip')
    D.to_csv(os.path.join(R, 'donor_microexon_psi.tsv'), sep='\t')

if __name__ == '__main__':
    main()
