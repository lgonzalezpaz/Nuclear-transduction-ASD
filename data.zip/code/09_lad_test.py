#!/usr/bin/env python3
"""Step 9. Data test of the mechanical (nuclear-envelope/LINC) null: force transmitted to the nucleus acts first on
lamina-associated chromatin; if mechanical transduction mattered, ASD splicing changes should be enriched in exons
located in lamina-associated domains (LADs; Guelen et al. 2008, UCSC hg19 track laminB1Lads).
Output: results/T7_lad.tsv
"""
import os, json, urllib.request, numpy as np, pandas as pd, statsmodels.api as sm
from scipy import stats

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, 'data', 'raw'); R = os.path.join(ROOT, 'results')
URL = 'https://api.genome.ucsc.edu/getData/track?genome=hg19;track=laminB1Lads'

def lads():
    f = os.path.join(RAW, 'laminB1Lads_hg19.tsv')
    if not os.path.exists(f):
        with urllib.request.urlopen(URL, timeout=120) as r:
            j = json.load(r)
        rows = []
        for c, v in j['laminB1Lads'].items() if isinstance(j['laminB1Lads'], dict) else [('all', j['laminB1Lads'])]:
            for x in v: rows.append((x['chrom'], x['chromStart'], x['chromEnd']))
        pd.DataFrame(rows, columns=['chrom', 'start', 'end']).to_csv(f, sep='\t', index=False)
    return pd.read_csv(f, sep='\t')

def main():
    L = lads(); print('LADs', len(L), 'covering', (L.end - L.start).sum() / 1e6, 'Mb')
    d = pd.read_csv(os.path.join(R, 'exon_dpsi.tsv'), sep='\t', index_col=0)
    d = d[d.dpsi.notna()].copy(); d['lad'] = 0
    for c, g in L.groupby('chrom'):
        s = np.sort(g.start.values); e = g.end.values[np.argsort(g.start.values)]
        m = d.chrom == c; pos = d.loc[m, 'eS'].values
        k = np.searchsorted(s, pos, side='right') - 1
        d.loc[m, 'lad'] = ((k >= 0) & (pos < e[np.clip(k, 0, None)])).astype(int)
    p = d.psi_ctl.clip(0.01, 0.99); X = pd.DataFrame({'lad': d.lad, 'p1': p - .5, 'p2': (p - .5) ** 2, 'micro': d.micro})
    f = sm.WLS(d.dpsi, sm.add_constant(X), weights=1 / d.se ** 2).fit()
    a, b = d.loc[d.lad == 1, 'dpsi'], d.loc[d.lad == 0, 'dpsi']
    za, zb = (d.dpsi / d.se)[d.lad == 1].abs(), (d.dpsi / d.se)[d.lad == 0].abs()
    T = pd.DataFrame([dict(n_lad=len(a), n_nonlad=len(b), frac_lad=d.lad.mean(), mean_dpsi_lad=a.mean(), mean_dpsi_nonlad=b.mean(),
                           b_lad=f.params['lad'], se_lad=f.bse['lad'], p_lad=f.pvalues['lad'],
                           median_absz_lad=za.median(), median_absz_nonlad=zb.median(), p_absz=stats.mannwhitneyu(za, zb)[1])])
    T.to_csv(os.path.join(R, 'T7_lad.tsv'), sep='\t', index=False); print(T.T)

if __name__ == '__main__':
    main()
