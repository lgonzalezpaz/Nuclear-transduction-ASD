#!/usr/bin/env python3
"""Step 5. Confronting H-E and H-K with the exon-level ASD splicing profile and with neuronal activity data.

T1  Model selection on composition-adjusted ASD dPSI (weighted least squares, AIC/BIC, likelihood-ratio tests,
    gene-grouped cross-validation, permutation null).
T2  Direct experimental signatures (Srrm4-KO dPSI, slow Pol II dPSI) on the exons where both were measured.
T3  Within-gene coherence (ICC) of ASD splicing changes: elongation changes act on whole transcription units,
    scaffold-dependent changes act through cis-elements of individual exons.
T4  Which signature predicts exons that respond to neuronal depolarization (KCl) in primary neurons.
Outputs: results/T1_model_selection.tsv, results/T2_direct.tsv, results/T3_icc.tsv, results/T4_kcl.tsv
"""
import os, numpy as np, pandas as pd, statsmodels.api as sm
from scipy import stats
from sklearn.model_selection import GroupKFold

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'data', 'processed'); R = os.path.join(ROOT, 'results')
rng = np.random.default_rng(20261019)

def load():
    d = pd.read_csv(os.path.join(R, 'exon_dpsi.tsv'), sep='\t', index_col=0)
    s = pd.read_csv(os.path.join(R, 'exon_scores.tsv'), sep='\t', index_col=0)
    m = pd.read_csv(os.path.join(P, 'mouse_sets_hg19.tsv'), sep='\t', index_col=0); m.columns = [c.replace('.', '_') for c in m.columns]
    d = d.join(s).join(m)
    d = d[d.dpsi.notna() & d.se.notna() & (d.se > 0)].copy()
    p = d.psi_ctl.clip(0.01, 0.99)
    d['pq'] = p * (1 - p)
    d['E'] = (d.E_score - d.E_score.mean()) / d.E_score.std()
    d['K'] = (d.K_score - d.K_score.mean()) / d.K_score.std()
    d['Ex'] = d.E * d.pq / d.pq.mean()          # logit-shift form of a scaffold (condensate) perturbation
    d['Dz'] = (d.D_score - d.D_score.mean()) / d.D_score.std()
    for k in range(1, 4): d[f'p{k}'] = (p - 0.5) ** k   # baseline-PSI polynomial (bounded-scale nuisance)
    return d

NUIS = ['p1', 'p2', 'p3']

def wls(y, X, w):
    return sm.WLS(y, sm.add_constant(X), weights=w).fit()

def cv_r2(d, cols, ycol='dpsi', k=10):
    """Gene-grouped k-fold out-of-sample weighted R2."""
    y = d[ycol].values; w = 1 / d.se.values ** 2; X = sm.add_constant(d[cols].values) if cols else np.ones((len(d), 1))
    pred = np.zeros(len(y))
    for tr, te in GroupKFold(k).split(X, y, d.locus.values):
        b = np.linalg.lstsq(X[tr] * np.sqrt(w[tr])[:, None], y[tr] * np.sqrt(w[tr]), rcond=None)[0]
        pred[te] = X[te] @ b
    ybar = np.sum(w * y) / np.sum(w)
    return 1 - np.sum(w * (y - pred) ** 2) / np.sum(w * (y - ybar) ** 2)

def T1(d, ycol='dpsi', secol='se', tag='all ages'):
    rows = []
    dd = d[d[ycol].notna() & (d[secol] > 0)].copy(); dd['se'] = dd[secol]
    w = 1 / dd.se ** 2
    specs = {'M0 nuisance': [], 'H-E': ['Ex'], 'H-K': ['K'], 'H-E + H-K': ['Ex', 'K'],
             'M0 + differentiation axis': ['Dz'], 'H-E + D': ['Ex', 'Dz'], 'H-K + D': ['K', 'Dz'], 'H-E + H-K + D': ['Ex', 'K', 'Dz']}
    base = None
    for name, cols in specs.items():
        f = wls(dd[ycol], dd[NUIS + cols], w)
        r = dict(outcome=tag, model=name, k=len(cols) + len(NUIS) + 1, llf=f.llf, AIC=f.aic, BIC=f.bic,
                 cvR2=cv_r2(dd, NUIS + cols, ycol))
        for c in ['Ex', 'K', 'Dz']:
            if c in cols:
                r[f'b_{c}'] = f.params[c]; r[f'se_{c}'] = f.bse[c]; r[f'p_{c}'] = f.pvalues[c]
        rows.append(r)
    T = pd.DataFrame(rows); T['dAIC'] = T.AIC - T.AIC.min()
    # posterior model probabilities from BIC (approximate Bayes factors), core four models
    core = T.model.isin(['M0 nuisance', 'H-E', 'H-K', 'H-E + H-K'])
    b = T.loc[core, 'BIC']; T.loc[core, 'P_BIC'] = np.exp(-(b - b.min()) / 2) / np.exp(-(b - b.min()) / 2).sum()
    return T

def perm_null(d, col, nperm=2000):
    """Permutation null for a score coefficient: scores permuted within baseline-PSI x exon-length strata."""
    w = 1 / d.se ** 2
    obs = wls(d.dpsi, d[NUIS + [col]], w).tvalues[col]
    strata = pd.qcut(d.psi_ctl, 10, labels=False, duplicates='drop').astype(str) + '_' + pd.qcut(np.log(d.L), 5, labels=False, duplicates='drop').astype(str)
    v = d[col].values.copy(); null = np.zeros(nperm)
    idx = [np.where(strata.values == s)[0] for s in np.unique(strata)]
    X0 = sm.add_constant(d[NUIS].values); sw = np.sqrt(w.values); y = d.dpsi.values
    for b in range(nperm):
        vp = v.copy()
        for ii in idx: vp[ii] = v[rng.permutation(ii)]
        X = np.column_stack([X0, vp]) * sw[:, None]
        beta, res, *_ = np.linalg.lstsq(X, y * sw, rcond=None)
        e = y * sw - X @ beta; s2 = e @ e / (len(y) - X.shape[1])
        cov = s2 * np.linalg.inv(X.T @ X); null[b] = beta[-1] / np.sqrt(cov[-1, -1])
    return obs, (np.sum(np.abs(null) >= abs(obs)) + 1) / (nperm + 1)

def T2(d):
    rows = []
    x = d.dropna(subset=['srrm4_dPSI']); rows.append(dict(set='Srrm4-KO dPSI (measured)', n=len(x), rho=stats.spearmanr(x.srrm4_dPSI, x.dpsi)[0],
        p=stats.spearmanr(x.srrm4_dPSI, x.dpsi)[1], frac_lower_ASD=(x.dpsi < 0).mean(), mean_dpsi=x.dpsi.mean()))
    for c, lab in [('slow_dPSI_ms_mw', 'slow Pol II, motor neurons'), ('slow_dPSI_ns_nw', 'slow Pol II, NPC'), ('slow_dPSI_es_ew', 'slow Pol II, ESC')]:
        x = d.dropna(subset=[c]); r = stats.spearmanr(x[c], x.dpsi)
        # partial: residualise on differentiation axis (WT MN vs ESC) and baseline PSI
        xx = x.dropna(subset=['slow_dPSI_mw_ew'])
        Z = sm.add_constant(xx[['slow_dPSI_mw_ew', 'p1', 'p2']])
        ra = sm.OLS(stats.rankdata(xx[c]), Z).fit().resid; rb = sm.OLS(stats.rankdata(xx.dpsi), Z).fit().resid
        pr = stats.pearsonr(ra, rb)
        rows.append(dict(set=lab, n=len(x), rho=r[0], p=r[1], partial_rho=pr[0], partial_p=pr[1], n_partial=len(xx)))
    # head-to-head on exons with both measurements
    x = d.dropna(subset=['srrm4_dPSI', 'slow_dPSI_ms_mw'])
    rows.append(dict(set='overlap (both measured)', n=len(x), rho=stats.spearmanr(x.srrm4_dPSI, x.dpsi)[0] if len(x) > 5 else np.nan,
                     partial_rho=stats.spearmanr(x.slow_dPSI_ms_mw, x.dpsi)[0] if len(x) > 5 else np.nan))
    return pd.DataFrame(rows)

def icc(z, g):
    df = pd.DataFrame({'z': z, 'g': g}); df = df[df.groupby('g').z.transform('size') >= 2]
    k = df.groupby('g').size(); n0 = (len(df) - (k ** 2).sum() / len(df)) / (len(k) - 1)
    msb = (df.groupby('g').z.mean() - df.z.mean()) ** 2 @ k / (len(k) - 1)
    msw = ((df.z - df.groupby('g').z.transform('mean')) ** 2).sum() / (len(df) - len(k))
    return (msb - msw) / (msb + (n0 - 1) * msw), len(k), len(df)

def T3(d, nperm=2000):
    w = 1 / d.se ** 2
    rows = []
    for lab, cols in [('raw z', None), ('residual after cis-scores (E, K) + baseline PSI', NUIS + ['Ex', 'K'])]:
        z = d.dpsi / d.se if cols is None else wls(d.dpsi, d[cols], w).resid * np.sqrt(w)
        obs, nl, ne = icc(z.values, d.locus.values)
        null = np.array([icc(z.values, rng.permutation(d.locus.values))[0] for _ in range(nperm // 10)])
        rows.append(dict(signal=lab, ICC=obs, loci=nl, exons=ne, null_mean=null.mean(), null_sd=null.std(),
                         p_perm=(np.sum(null >= obs) + 1) / (len(null) + 1)))
    # stratify: exons with high vs low elongation sensitivity |K|
    hi = d.K.abs() >= d.K.abs().quantile(0.75)
    for lab, m in [('high |K| exons', hi), ('low |K| exons', ~hi)]:
        dd = d[m]; obs, nl, ne = icc((dd.dpsi / dd.se).values, dd.locus.values)
        rows.append(dict(signal=lab, ICC=obs, loci=nl, exons=ne))
    return pd.DataFrame(rows)

def T4(d):
    """KCl-responsive exons (frameshifting subset, Kim et al. 2025) within the orthologous universe."""
    u = d[d.slow_EVENT.notna() | d.kcl_gene.notna() | d.srrm4_event.notna()].copy()
    u['y'] = u.kcl_gene.notna().astype(int)
    u = u[(u.L % 3 != 0) | (u.y == 1)]  # the KCl table lists frameshifting exons only: compare like with like
    rows = []
    for name, cols in {'E': ['E'], 'K': ['K'], 'E+K': ['E', 'K']}.items():
        f = sm.Logit(u.y, sm.add_constant(u[cols + ['p1', 'p2']])).fit(disp=0)
        r = dict(model=name, n=len(u), n_kcl=int(u.y.sum()), AIC=f.aic, llf=f.llf)
        for c in cols: r[f'OR_{c}'] = np.exp(f.params[c]); r[f'p_{c}'] = f.pvalues[c]
        rows.append(r)
    # ASD dPSI of KCl-responsive exons
    k = d.kcl_gene.notna()
    rows.append(dict(model='ASD dPSI KCl vs other', n=int(k.sum()), AIC=np.nan,
                     OR_E=d.loc[k, 'dpsi'].mean(), OR_K=d.loc[~k, 'dpsi'].mean(),
                     p_E=stats.mannwhitneyu(d.loc[k, 'dpsi'], d.loc[~k, 'dpsi'])[1]))
    return pd.DataFrame(rows)

def main():
    d = load()
    print('exons analysed', len(d), 'loci', d.locus.nunique())
    t1 = pd.concat([T1(d), T1(d, 'dpsi_1030', 'se_1030', '10-30 y')])
    for c in ['Ex', 'K']:
        o, p = perm_null(d, c); t1.loc[(t1.outcome == 'all ages') & (t1.model == ('H-E' if c == 'Ex' else 'H-K')), 'p_perm'] = p
        print(f'permutation (PSI x length strata) {c}: t={o:.2f} p={p:.4f}')
    t1.to_csv(os.path.join(R, 'T1_model_selection.tsv'), sep='\t', index=False)
    print(t1[['outcome', 'model', 'dAIC', 'BIC', 'P_BIC', 'cvR2', 'b_Ex', 'p_Ex', 'b_K', 'p_K', 'b_Dz', 'p_Dz']].round(5).to_string())
    t2 = T2(d); t2.to_csv(os.path.join(R, 'T2_direct.tsv'), sep='\t', index=False); print(t2.round(4).to_string())
    t3 = T3(d); t3.to_csv(os.path.join(R, 'T3_icc.tsv'), sep='\t', index=False); print(t3.round(4).to_string())
    t4 = T4(d); t4.to_csv(os.path.join(R, 'T4_kcl.tsv'), sep='\t', index=False); print(t4.round(4).to_string())

if __name__ == '__main__':
    main()
