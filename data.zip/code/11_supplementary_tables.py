#!/usr/bin/env python3
"""Step 11. Supplementary Data workbook (one sheet per Supplementary Table) and exon-level source data."""
import os, pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = os.path.join(ROOT, 'results'); P = os.path.join(ROOT, 'data', 'processed')

SOURCES = pd.DataFrame([
    ('Cassette-exon PSI, cortex and cerebellar vermis', 'Parikshak et al. 2016 Nature 540:423', 'github.com/dhglab/Genome-wide-changes-in-lncRNA-alternative-splicing-and-cortical-patterning-in-autism (commit b9c61ac)', 'ASD_PSI_Data.Rdata; SuppTable2A.csv'),
    ('Cortical bulk RNA-seq (composition, activity, OXPHOS indices)', 'Gandal et al. 2022 Nature 611:532', 'github.com/dhglab/Broad-transcriptomic-dysregulation-across-the-cerebral-cortex-in-ASD (commit 6821cc5)', '02_01_A_AllProcessedData_wModelMatrix.RData'),
    ('Srrm4-mutant splicing changes (cortex, hippocampus)', 'Quesnel-Vallieres et al. 2015 Genes Dev 29:746', 'Europe PMC PMC4387716', 'Table S2'),
    ('Slow (R749H) Pol II splicing changes; elongation rates; expression', 'Maslon et al. 2019 EMBO J 38:e101244', 'Europe PMC PMC6484407', 'Tables EV1, EV2, EV3'),
    ('KCl-responsive exons in primary neurons', 'Krick et al. 2025 Genome Res 35:1301', 'Europe PMC PMC12129014', 'Supplementary Table 9'),
    ('Spine density, ASD/control', 'Tang et al. 2014 Neuron 83:1131', 'published values', 'ratios 1.084 +/- 0.037 (2-9 y), 1.655 +/- 0.088 (13-20 y)'),
    ('Neocortical ATP budget', 'Harris, Jolivet & Attwell 2012 Neuron 75:762', 'published values', 'housekeeping 25%; synaptic 58%, AP 22%, resting 20% of signalling'),
    ('hg19 sequence; liftOver chains and binary', 'Kent et al. 2002 Genome Res 12:996', 'hgdownload.soe.ucsc.edu', 'hg19.2bit; mm9ToHg19, mm10ToHg19, mm39ToMm10 chains'),
    ('Lamina-associated domains (Tig3 fibroblasts)', 'Guelen et al. 2008 Nature 453:948', 'api.genome.ucsc.edu track laminB1Lads (hg19)', 'laminB1Lads_hg19.tsv'),
    ('MaxEntScan splice-site models', 'Yeo & Burge 2004 J Comput Biol 11:377', 'github.com/kepbod/maxentpy (commit b5e69aa)', 'me2x5, splice5sequences, me2x3acc'),
], columns=['Data', 'Reference', 'Location (pinned version)', 'Files / values'])

def rd(f, **k): return pd.read_csv(os.path.join(R, f), sep='\t', **k)

def main():
    out = os.path.join(R, 'Supplementary_Data.xlsx')
    with pd.ExcelWriter(out) as w:
        SOURCES.to_excel(w, sheet_name='S1_data_sources', index=False)
        sig = rd('signature_coefficients.tsv', index_col=0); sig.index.name = 'feature'
        sig.to_excel(w, sheet_name='S2_fingerprint_weights'); rd('signature_models.tsv').to_excel(w, sheet_name='S2b_fingerprint_CV', index=False)
        rd('T1_model_selection.tsv').to_excel(w, sheet_name='S3_model_selection', index=False)
        rd('T6_robustness.tsv').to_excel(w, sheet_name='S4_robustness', index=False)
        rd('T2_direct.tsv').to_excel(w, sheet_name='S5_direct_signatures', index=False)
        rd('T3_icc.tsv').to_excel(w, sheet_name='S6_within_gene_ICC', index=False)
        rd('T4_kcl.tsv').to_excel(w, sheet_name='S7_KCl_exons', index=False)
        rd('T5_donor_tests.tsv').to_excel(w, sheet_name='S8_donor_tests', index=False)
        rd('biophysics_observed_age.tsv').to_excel(w, sheet_name='S9_age_profile', index=False)
        rd('biophysics_channel_comparison.tsv').to_excel(w, sheet_name='S10_channel_comparison', index=False)
        rd('biophysics_abc_posterior.tsv').to_excel(w, sheet_name='S11_ABC_posterior', index=False)
        pd.concat([rd(f, index_col=0).iloc[:, 0].rename('value') for f in ['biophysics_load.tsv', 'biophysics_energetic_feasibility.tsv',
                   'biophysics_criticality.tsv', 'biophysics_subgroup.tsv', 'biophysics_mechanical.tsv']]).to_frame().to_excel(w, sheet_name='S12_biophysical_summary')
        rd('biophysics_subgroup_scan.tsv').to_excel(w, sheet_name='S13_subgroup_scan', index=False)
        rd('biophysics_elongation.tsv').to_excel(w, sheet_name='S14_elongation_calibration', index=False)
        rd('biophysics_sobol.tsv').to_excel(w, sheet_name='S15_Sobol', index=False)
        rd('T7_lad.tsv').to_excel(w, sheet_name='S16_LAD_test', index=False)
        rd('sf_expression.tsv').to_excel(w, sheet_name='S17_SF_expression', index=False)
        rd('transfer_calibration.tsv', index_col=0).iloc[:, 0].rename('value').to_frame().to_excel(w, sheet_name='S18_transfer_calibration')
        rd('biophysics_emergent_hill_summary.tsv', index_col=0).iloc[:, 0].rename('value').to_frame().to_excel(w, sheet_name='S19_emergent_Hill')
    ex = rd('exon_dpsi.tsv', index_col=0).join(rd('exon_scores.tsv', index_col=0))
    ex = ex[ex.dpsi.notna()]
    cols = ['chrom', 'strand', 'eS', 'eE', 'L', 'micro', 'psi_ctl', 'psi_asd', 'dpsi', 'se', 'p', 'dpsi_1030', 'se_1030', 'dpsi_raw', 'se_raw',
            'me3', 'me5', 'me3_down', 'me5_up', 'Lup', 'Ldn', 'ugc', 'pyr', 'gcatg_up', 'gcatg_dn', 'gc_exon', 'gc_flank', 'locus', 'E_score', 'K_score', 'D_score']
    ex[cols].to_csv(os.path.join(R, 'Source_Data_exon_level.csv.gz'), compression='gzip')
    print('written', out, 'and exon-level source data for', len(ex), 'exons')

if __name__ == '__main__':
    main()
