#!/usr/bin/env python3
"""Step 2. Parse independent, experimentally derived exon-level perturbation datasets (mouse) and map them
onto the human cortical cassette exons by liftOver.

(a) Srrm4/nSR100 dependency: Quesnel-Vallieres et al. 2015 Genes Dev, Table S2 (Srrm4 KO vs WT cortex/hippocampus,
    VAST-TOOLS, mm9).
(b) RNA Pol II elongation-rate dependency: Maslon et al. 2019 EMBO J, Table EV3 (slow R749H Pol II knock-in vs WT
    in ESC, NPC and motor neurons, VAST-TOOLS, mm9).
(c) Neuronal-activity dependency: Kim et al. 2025 Genome Res, Table S9 (frameshifting KCl-dependent exons in five
    primary-neuron datasets, mm39), used as an activity-regulated exon set.
Output: data/processed/mouse_sets_hg19.tsv (one row per human exon with matched annotations)
"""
import os, re, gzip, numpy as np, pandas as pd, pdfplumber

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, 'data', 'raw'); OUT = os.path.join(ROOT, 'data', 'processed')
G = os.path.join(RAW, 'genome')

def parse_qv():
    rows = []
    with pdfplumber.open(os.path.join(RAW, 'supp', 'qv', 'supp_29.7.746_Table_S2.pdf')) as p:
        for pg in p.pages:
            for l in pg.extract_text().split('\n'):
                l = l.replace('­', '').replace('‐', '-').replace('--', '-')
                l = re.sub(r'-+', '-', l)
                f = l.split()
                if len(f) < 7 or not f[1].startswith('Mmu'):
                    continue
                m = re.match(r'(chr\w+):(\d+)-(\d+)', f[2])
                if not m:
                    continue
                try:
                    rows.append(dict(gene=f[0], event=f[1], chrom=m.group(1), start=int(m.group(2)), end=int(m.group(3)),
                                     type=f[4], p=float(f[5]), dPSI=float(f[6])))
                except ValueError:
                    continue
    d = pd.DataFrame(rows)
    return d[d.type == 'AltEx'].copy()

def parse_maslon():
    d = pd.read_excel(os.path.join(RAW, 'supp', 'mas', 'EMBJ-38-e101244-s005.xlsx'))
    m = d.COORD.str.extract(r'(chr\w+):(\d+)-(\d+)')
    d['chrom'] = m[0]; d['start'] = m[1].astype(float); d['end'] = m[2].astype(float)
    return d.dropna(subset=['start'])

def parse_kcl():
    x = pd.read_excel(os.path.join(RAW, 'supp', 'gr', 'supplemental_table_9_kcl_exon_pfam_domain_overlap.xlsx'),
                      sheet_name=None, header=2)
    out = []
    for s, d in x.items():
        d = d[['exon_chr', 'exon_start', 'exon_end', 'exon_gene_name', 'exon_strand']].drop_duplicates()
        d.columns = ['chrom', 'start', 'end', 'gene', 'strand']; d['window'] = s.split()[0]
        out.append(d)
    return pd.concat(out).drop_duplicates(['chrom', 'start', 'end'])

def lift(df, chains):
    """Exon intervals lifted with the UCSC liftOver binary (minMatch 0.5), chained if needed; intervals whose
    lifted length differs from the original by >10% (or >3 nt) are discarded."""
    import subprocess, tempfile
    tmp = tempfile.mkdtemp()
    bed = os.path.join(tmp, 'in.bed')
    d = df.reset_index(drop=True).copy(); d['uid'] = np.arange(len(d))
    pd.DataFrame({'c': d.chrom, 's': d.start.astype(int) - 1, 'e': d.end.astype(int), 'n': d.uid}).to_csv(bed, sep='\t', header=False, index=False)
    for k, c in enumerate(chains):
        out = os.path.join(tmp, f'out{k}.bed')
        subprocess.run([os.path.join(G, 'liftOver'), '-minMatch=0.5', bed, os.path.join(G, c), out, os.path.join(tmp, 'un.bed')],
                       check=True, capture_output=True)
        bed = out
    L = pd.read_csv(bed, sep='\t', header=None, names=['hchrom', 'hstart0', 'hend', 'uid'])
    L['hstart'] = L.hstart0 + 1
    d = d.merge(L[['uid', 'hchrom', 'hstart', 'hend']], on='uid')
    lo, lh = d.end - d.start, d.hend - d.hstart
    return d[np.abs(lh - lo) <= np.maximum(3, 0.1 * lo)].copy()

def match(ex, ms, cols, tag):
    """Assign each human exon the mouse event whose lifted interval overlaps it (max reciprocal overlap)."""
    out = {}
    byc = {c: g for c, g in ms.groupby('hchrom')}
    for ev, r in ex.iterrows():
        g = byc.get(r.chrom)
        if g is None: continue
        hs, he = r.eS, r.eE  # 0-based start, 1-based end
        ov = np.minimum(he, g.hend.values + 1) - np.maximum(hs, g.hstart.values - 1)
        k = np.where(ov > 0)[0]
        if len(k) == 0: continue
        L = he - hs; Lm = (g.hend.values[k] - g.hstart.values[k] + 1)
        score = ov[k] / np.maximum(L, Lm)
        j = k[np.argmax(score)]
        if score.max() >= 0.5:
            out[ev] = {f'{tag}_{c}': g.iloc[j][c] for c in cols}
    return pd.DataFrame.from_dict(out, orient='index')

def main():
    ex = pd.read_csv(os.path.join(OUT, 'exons_features.tsv'), sep='\t', index_col=0)
    qv = lift(parse_qv(), ['mm9ToHg19.over.chain.gz'])
    ma = lift(parse_maslon(), ['mm9ToHg19.over.chain.gz'])
    kc = lift(parse_kcl(), ['mm39ToMm10.over.chain.gz', 'mm10ToHg19.over.chain.gz'])
    print('lifted: Srrm4-KO', len(qv), '| slow-PolII', len(ma), '| KCl', len(kc))
    A = match(ex, qv, ['event', 'dPSI', 'p'], 'srrm4')
    B = match(ex, ma, ['EVENT', 'dPSI.es.ew', 'dPSI.ns.nw', 'dPSI.ms.mw', 'signif.es.ew', 'signif.ns.nw', 'signif.ms.mw',
                       'dPSI.mw.ew'], 'slow')
    C = match(ex, kc, ['gene', 'window'], 'kcl')
    M = pd.DataFrame(index=ex.index).join(A).join(B).join(C)
    M.to_csv(os.path.join(OUT, 'mouse_sets_hg19.tsv'), sep='\t')
    print('matched human exons: Srrm4', A.shape[0], '| slow PolII', B.shape[0], '| KCl', C.shape[0])

if __name__ == '__main__':
    main()
