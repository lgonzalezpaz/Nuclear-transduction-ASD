"""Biophysical transduction models linking circuit activity of an under-pruned cortex to nuclear splicing.

H-E  ('the unpruned circuit exhausts the nucleus'): activity -> nuclear Ca2+/CaMK -> phosphorylation of the
     microexon-activation scaffold (SRRM4-SRSF11-RNPS1) + ATP supply-demand imbalance -> loss of functional
     condensate (lever rule) -> microexon skipping.
H-K  ('the unpruned circuit accelerates or brakes transcription'): activity -> intragenic chromatin change ->
     RNA polymerase II elongation rate v -> window-of-opportunity kinetic competition -> inclusion change.
H-M  (null, mechanical): traction forces of synapse elimination transmitted to the nucleus (LINC complex).
All quantities are dimensionless and relative to the neurotypical adult set point unless stated.
"""
import numpy as np
from scipy.optimize import brentq

# --- mean-field activity map of a recurrent cortical circuit with homeostatic brake ---
# default values = mid-points of the literature-informed prior ranges (Table 1 of the article)
ACT = dict(Cb=0.175, q=1.75, eta=1.0, kappa=0.5, KC=2.0, n=3.5)

def hill(C, K, n):
    C = np.asarray(C, float)
    return C ** n / (K ** n + C ** n)

def activity_from_spines(Nr, Cb=ACT['Cb'], q=ACT['q'], eta=ACT['eta'], kappa=ACT['kappa'], KC=ACT['KC'], n=ACT['n']):
    """Activity C solving C = Cb + (1-Cb) Nr^q / H(C)^eta, H(C) = 1 + kappa [A(C) - A(1)] (equation 1)."""
    h1 = hill(1.0, KC, n)
    f = lambda C: Cb + (1 - Cb) * Nr ** q / (1 + kappa * (hill(C, KC, n) - h1)) ** eta - C
    return brentq(f, 1e-4, 1e4)

# --- energetics (Harris, Jolivet & Attwell 2012 budget) ---
F_HK = 0.25                                   # housekeeping share of total ATP use
F_SYN, F_AP, F_REST = 0.58, 0.22, 0.20        # shares of signalling ATP: synaptic (post+presyn+glu cycling), APs, resting

def atp_demand(C, Nr):
    """Relative ATP demand j (=1 at set point): synaptic costs scale with synapse number x rate, AP with rate."""
    return F_HK + (1 - F_HK) * (F_SYN * Nr * C + F_AP * C + F_REST)

def atp_ratio(j, SRC, a0=0.9, chronic=0.0):
    """Steady-state ATP/(ATP+ADP) relative to baseline for ADP-driven OXPHOS supply V = Vmax (1-a)/(K+1-a)
    with spare respiratory capacity SRC = Vmax/V(a0); chronic = fraction of the extra demand met by adaptive
    capacity (mitochondrial biogenesis/glycolysis) in chronic hyperactivity."""
    j = 1 + (np.asarray(j, float) - 1) * (1 - chronic)
    K = (1 - a0) * (SRC - 1)
    j = np.minimum(j, SRC * 0.999)
    one_minus_a = K * j / (SRC - j)
    return np.clip(1 - one_minus_a, 1e-3, 1) / a0

# --- condensate (lever rule) ---
def s_eff(phi, atp_r, rho0, gamma, mu, phi0, s_tot=1.0):
    """Functional condensed scaffold relative to baseline.
    phi: phosphorylated (inactivated) fraction; c_sat rises as exp(gamma (phi - phi0)) because phosphorylation
    removes sticker valence; rho0 = c/c_sat at baseline (supersaturation); lever-rule condensed amount
    max(0, s_tot*rho0 - c_sat_rel); ATP-dependent liquidity (atp_r)^mu."""
    csat = np.exp(gamma * (np.asarray(phi, float) - phi0))
    cond = np.maximum(0.0, s_tot * rho0 - csat) / (rho0 - 1.0)
    return cond * np.asarray(atp_r, float) ** mu

def phi_of_C(C, phi0, KC=ACT['KC'], n=ACT['n']):
    return np.clip(phi0 * hill(C, KC, n) / hill(1.0, KC, n), 0, 1)

def micro_psi(S, Imax, K0, h0):
    S = np.maximum(np.asarray(S, float), 0)
    return Imax * S ** h0 / (K0 ** h0 + S ** h0)

def effective_hill(rho0, K0, h0, s=np.linspace(0.02, 2.0, 400)):
    """Fit an apparent Hill function I = Imax s^h/(K^h+s^h) to the condensate transfer function I(s_tot)."""
    from scipy.optimize import curve_fit
    I = micro_psi(np.maximum(0, s * rho0 - 1) / (rho0 - 1), 1.0, K0, h0)
    f = lambda s, Im, K, h: Im * s ** h / (K ** h + s ** h)
    try:
        p, _ = curve_fit(f, s, I, p0=[1.0, 1 / rho0 + 0.1, 4], bounds=([0.5, 1e-3, 0.5], [1.5, 2, 40]), maxfev=20000)
    except Exception:
        return np.nan, np.nan
    return p[2], p[1]

# --- kinetic coupling (window of opportunity) ---
def kinetic_psi(x, r):
    """PSI = 1 - (1-r) exp(-x): x = k_a * tau (recognition rate x time until the competing downstream exon is
    synthesised, tau = L_down / v); r = probability of inclusion once both exons compete post-transcriptionally."""
    return 1 - (1 - r) * np.exp(-x)

def kinetic_dpsi(x, r, dlnv):
    """Exact inclusion change after a change in elongation rate v -> v exp(dlnv) (x scales as 1/v)."""
    return kinetic_psi(x * np.exp(-dlnv), r) - kinetic_psi(x, r)

def dlnv_of_C(C, kv, KC=ACT['KC'], n=ACT['n']):
    a1 = hill(1.0, KC, n)
    return kv * (hill(C, KC, n) - a1) / (1 - a1)

# --- mechanical null (order of magnitude, Monte Carlo over literature ranges) ---
def mech_draws(n, rng):
    lu = lambda a, b: np.exp(rng.uniform(np.log(a), np.log(b), n))
    d = dict(F=lu(10e-12, 1e-9),             # N, force per elimination contact (filopodia ~10-100 pN; phagocytic cups ~nN)
             dist=lu(20e-6, 300e-6),        # m, spine-to-soma path length (human pyramidal dendrites)
             lam=lu(5e-6, 100e-6),          # m, decay length of tension along a neurite with adhesions/anchoring
             spines=lu(5e3, 3e4),           # spines per pyramidal neuron
             elim=lu(0.005, 0.03),          # fraction eliminated per day
             dur=lu(5, 60),                 # min, duration of a microglial/astrocytic elimination contact
             deficit=rng.uniform(0.2, 0.6, n),  # fractional reduction of elimination in the pruning deficit
             Fbasal=lu(0.5e-9, 10e-9))      # N, basal cytoskeletal load on the nucleus (actomyosin prestress)
    conc = d['spines'] * d['elim'] * d['dur'] / 1440.0           # elimination contacts in progress at any time
    # contacts act in random directions: the net force grows as sqrt(n) for n >= 1 concurrent contacts and as the
    # time fraction n for n < 1 (upper bound: no cancellation within a contact, no viscous dissipation)
    eff = np.where(conc < 1, conc, np.sqrt(conc))
    dF = d['deficit'] * eff * d['F'] * np.exp(-d['dist'] / d['lam'])
    d['dF'] = dF; d['ratio'] = dF / d['Fbasal']
    return d
