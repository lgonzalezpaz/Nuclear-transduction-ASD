#!/usr/bin/env python3
"""Step 6. Donor-level tests: switch-like (threshold) versus graded responses, and coupling of each channel to
neuronal activity (immediate-early genes) and oxidative-phosphorylation capacity.

For every sample, PSI is residualised on covariates and cell-type composition (diagnosis not in the model), and two
indices are formed: the scaffold index (mean residual inclusion of the top-decile E-score exons) and the
elongation index (mean residual of the top-decile |K| exons, oriented so that positive = 'slow-Pol-II-like').
Outputs: results/donor_indices.tsv, results/T5_donor_tests.tsv
"""
import os, numpy as np, pandas as pd, statsmodels.api as sm
from scipy import stats
from scipy.optimize import minimize

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'data', 'processed'); R = os.path.join(ROOT, 'results')
rng = np.random.default_rng(7)
MARK = ['neuron', 'astro', 'microglia', 'oligo', 'endo']

def mix_lrt(x, mu, sd, nboot=500):
    """Two-component mixture for ASD donors with one component fixed at the control distribution."""
    def nll(t, x):
        pi = 1 / (1 + np.exp(-t[0])); m2 = t[1]; s2 = np.exp(t[2])
        L = (1 - pi) * stats.norm.pdf(x, mu, sd) + pi * stats.norm.pdf(x, m2, s2)
        return -np.sum(np.log(L + 1e-300))
    def fit(x):
        best = None
        for m0 in np.quantile(x, [0.05, 0.2, 0.5, 0.8, 0.95]):
            r = minimize(nll, [0, m0, np.log(sd)], args=(x,), method='Nelder-Mead', options=dict(maxiter=4000))
            best = r if best is None or r.fun < best.fun else best
        return best
    r = fit(x); l0 = -np.sum(stats.norm.logpdf(x, mu, sd)); lrt = 2 * (l0 - r.fun)
    null = []
    for _ in range(nboot):
        xb = rng.normal(mu, sd, len(x)); rb = fit(xb); null.append(2 * (-np.sum(stats.norm.logpdf(xb, mu, sd)) - rb.fun))
    pi = 1 / (1 + np.exp(-r.x[0]))
    return lrt, (np.sum(np.array(null) >= lrt) + 1) / (nboot + 1), pi, r.x[1] - mu

def main():
    psi = pd.read_parquet(os.path.join(P, 'psi_ctx.parquet'))
    meta = pd.read_csv(os.path.join(P, 'meta_ctx.tsv'), sep='\t', index_col=0); meta.index = psi.columns
    cov = pd.read_csv(os.path.join(P, 'sample_covariates.tsv'), sep='\t', index_col=0).reindex(psi.columns)
    keep = (meta['Detailed.Diagnosis'] != 'Chromosome 15q Duplication Syndrome') & cov.neuron.notna()
    meta, cov, psi = meta[keep], cov[keep], psi.loc[:, keep.values]
    d = pd.read_csv(os.path.join(R, 'exon_dpsi.tsv'), sep='\t', index_col=0).join(pd.read_csv(os.path.join(R, 'exon_scores.tsv'), sep='\t', index_col=0))
    d = d[d.dpsi.notna()]
    psi = psi.loc[d.index]
    X = pd.DataFrame({'age': meta.Age, 'male': (meta.Sex == 'M') * 1.0, 'rin': meta.RIN, 'pmi': meta.PMI.fillna(meta.PMI.median()),
                      'ba9': (meta.RegionID == 'ba9') * 1.0}, index=meta.index)
    for c in ['SeqBatch', 'BrainBank']: X = X.join(pd.get_dummies(meta[c].astype(str), prefix=c, drop_first=True).astype(float))
    X = sm.add_constant(X.join(cov[MARK]).astype(float))
    # residualise each exon on covariates (NaN-aware, per exon)
    Y = psi.values; Rz = np.full(Y.shape, np.nan)
    for i in range(Y.shape[0]):
        m = ~np.isnan(Y[i]); b = np.linalg.lstsq(X.values[m], Y[i, m], rcond=None)[0]
        e = Y[i, m] - X.values[m] @ b; Rz[i, m] = e / (np.std(e) + 1e-9)
    Rz = pd.DataFrame(Rz, index=psi.index, columns=psi.columns)
    topE = d.E_score >= d.E_score.quantile(0.9)
    topK = d.K_score.abs() >= d.K_score.abs().quantile(0.9)
    signK = np.sign(d.K_score)
    S = pd.DataFrame(index=psi.columns)
    S['scaffold_index'] = Rz[topE.values].mean(0)
    S['elong_index'] = Rz[topK.values].mul(signK[topK].values, axis=0).mean(0)
    S['micro_index'] = Rz[(d.micro == 1).values].mean(0)
    S = S.join(meta[['BrainID', 'ASD.CTL', 'Age', 'RegionID']]).join(cov[['ieg', 'oxphos', 'caax'] + MARK])
    D = S.groupby('BrainID').agg({**{c: 'mean' for c in ['scaffold_index', 'elong_index', 'micro_index', 'ieg', 'oxphos', 'caax'] + MARK},
                                  'ASD.CTL': 'first', 'Age': 'first'})
    D.to_csv(os.path.join(R, 'donor_indices.tsv'), sep='\t')
    rows = []
    asd = D['ASD.CTL'] == 'ASD'
    for ix in ['scaffold_index', 'elong_index', 'micro_index']:
        a, c = D.loc[asd, ix], D.loc[~asd, ix]
        t = stats.ttest_ind(a, c, equal_var=False)
        lev = stats.levene(a, c)
        lrt, plrt, pi, delta = mix_lrt(a.values, c.mean(), c.std())
        r = dict(index=ix, n_asd=len(a), n_ctl=len(c), diff=a.mean() - c.mean(), t=t.statistic, p=t.pvalue,
                 sd_ratio=a.std() / c.std(), levene_p=lev.pvalue, skew_asd=stats.skew(a), mix_LRT=lrt, mix_p=plrt,
                 mix_pi=pi, mix_delta=delta)
        # coupling to activity and energetics within groups (adjusted for neuronal content and age)
        for g, m in [('ASD', asd), ('CTL', ~asd)]:
            for z in ['ieg', 'oxphos', 'caax']:
                Dm = D[m]; Z = sm.add_constant(Dm[[z, 'neuron', 'Age']])
                f = sm.OLS((Dm[ix] - Dm[ix].mean()) / Dm[ix].std(), Z.assign(**{z: (Dm[z] - Dm[z].mean()) / Dm[z].std()})).fit()
                r[f'beta_{z}_{g}'] = f.params[z]; r[f'p_{z}_{g}'] = f.pvalues[z]
        rows.append(r)
    T = pd.DataFrame(rows); T.to_csv(os.path.join(R, 'T5_donor_tests.tsv'), sep='\t', index=False)
    print(T.round(4).T.to_string())
    print('corr scaffold vs elongation index (donors):', stats.spearmanr(D.scaffold_index, D.elong_index))

if __name__ == '__main__':
    main()
