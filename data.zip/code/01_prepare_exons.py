#!/usr/bin/env python3
"""Step 1. Parse cassette exons (Parikshak et al. 2016), compute per-exon sequence and
architecture features from hg19, and per-donor composition-matched sample metadata.

Outputs: data/processed/exons_features.tsv, data/processed/psi_ctx.parquet, data/processed/meta_ctx.tsv
"""
import re, sys, os, numpy as np, pandas as pd, pyreadr, py2bit
from maxentpy import maxent
M3 = maxent.load_matrix3(); M5 = maxent.load_matrix5()  # MaxEntScan (Yeo & Burge 2004) models, loaded once

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, 'data', 'raw'); OUT = os.path.join(ROOT, 'data', 'processed')
os.makedirs(OUT, exist_ok=True)

COMP = str.maketrans('ACGTNacgtn', 'TGCANtgcan')
def rc(s): return s.translate(COMP)[::-1]

def parse_id(x):
    m = re.match(r'(chr[^-]+)-str\[(.)\]-eS-(\d+)-eE-(\d+)-ueS-(\d+)-ueE-(\d+)-deS-(\d+)-deE-(\d+)', x)
    c, s, eS, eE, ueS, ueE, deS, deE = m.groups()
    return dict(chrom=c, strand=s, eS=int(eS), eE=int(eE), ueS=int(ueS), ueE=int(ueE), deS=int(deS), deE=int(deE))

def main():
    r = pyreadr.read_r(os.path.join(RAW, 'parikshak', 'data', 'provided', 'ASD_PSI_Data.Rdata'))
    psi = r['datPSI.CTX']; meta = r['datMeta.CTX'].copy()
    psi_cbl = r['datPSI.CBL']; meta_cbl = r['datMeta.CBL'].copy()
    tb = py2bit.open(os.path.join(RAW, 'genome', 'hg19.2bit'))
    rows = []
    for ev in psi.index.union(psi_cbl.index):
        if not ev.startswith('chr'):
            continue  # non-cassette event formats (alternative 5'/3' sites, MXE) are not analysed
        d = parse_id(ev); d['event'] = ev; rows.append(d)
    ex = pd.DataFrame(rows).set_index('event')
    # coordinates follow the rMATS convention (0-based start, 1-based end) -> check dinucleotides
    def seq(c, a, b):
        return tb.sequence(c, max(a, 0), b).upper()
    ok = 0; n = 0
    for ev, d in ex.sample(500, random_state=1).iterrows():
        if d.strand == '+':
            acc = seq(d.chrom, d.eS - 2, d.eS); don = seq(d.chrom, d.eE, d.eE + 2)
        else:
            acc = rc(seq(d.chrom, d.eE, d.eE + 2)); don = rc(seq(d.chrom, d.eS - 2, d.eS))
        n += 1; ok += (acc == 'AG') and (don == 'GT')
    print(f'canonical AG/GT under 0-based-start convention: {ok}/{n}')
    feats = []
    for ev, d in ex.iterrows():
        c = d.chrom
        if d.strand == '+':
            up_int = seq(c, d.ueE, d.eS); dn_int = seq(c, d.eE, d.deS); exon = seq(c, d.eS, d.eE)
            s3 = seq(c, d.eS - 20, d.eS + 3); s5 = seq(c, d.eE - 3, d.eE + 6)
            s3d = seq(c, d.deS - 20, d.deS + 3); s5u = seq(c, d.ueE - 3, d.ueE + 6)
        else:
            # rMATS 'upstream/downstream' flanks are genomic (lower/higher coordinate); on '-' strand the
            # transcript-upstream exon is the genomic 'downstream' (de*) flank.
            up_int = rc(seq(c, d.eE, d.deS)); dn_int = rc(seq(c, d.ueE, d.eS)); exon = rc(seq(c, d.eS, d.eE))
            s3 = rc(seq(c, d.eE - 3, d.eE + 20)); s5 = rc(seq(c, d.eS - 6, d.eS + 3))
            s3d = rc(seq(c, d.ueE - 3, d.ueE + 20)); s5u = rc(seq(c, d.deS - 6, d.deS + 3))
        L = len(exon); Lup = len(up_int); Ldn = len(dn_int)
        def me3(s): return maxent.score3(s, matrix=M3) if len(s) == 23 and 'N' not in s else np.nan
        def me5(s): return maxent.score5(s, matrix=M5) if len(s) == 9 and 'N' not in s else np.nan
        # SRRM4/eMIC-associated motifs: UGC in the region between branch point and 3'ss (-60..-1)
        reg3 = up_int[-60:]
        ugc = len(re.findall('(?=TGC)', reg3)) / max(len(reg3), 1) * 100
        # polypyrimidine tract strength: fraction of pyrimidines in -25..-3
        ppt = up_int[-25:-3]; pyr = (ppt.count('C') + ppt.count('T')) / max(len(ppt), 1)
        # RBFOX motif (UGCAUG) in downstream (1..300) and upstream (-300..-1) intron
        gcatg_dn = len(re.findall('(?=TGCATG)', dn_int[:300])); gcatg_up = len(re.findall('(?=TGCATG)', up_int[-300:]))
        gc_ex = (exon.count('G') + exon.count('C')) / max(L, 1)
        gc_fl = ((up_int[-200:] + dn_int[:200]).count('G') + (up_int[-200:] + dn_int[:200]).count('C')) / max(len(up_int[-200:] + dn_int[:200]), 1)
        feats.append(dict(event=ev, L=L, Lup=Lup, Ldn=Ldn, me3=me3(s3), me5=me5(s5), me3_down=me3(s3d), me5_up=me5(s5u),
                          ugc=ugc, pyr=pyr, gcatg_dn=gcatg_dn, gcatg_up=gcatg_up, gc_exon=gc_ex, gc_flank=gc_fl,
                          frame=int(L % 3 == 0)))
    F = pd.DataFrame(feats).set_index('event')
    ex = ex.join(F)
    ex['micro'] = ((ex.L >= 3) & (ex.L <= 27)).astype(int)
    ex['in_ctx'] = ex.index.isin(psi.index).astype(int); ex['in_cbl'] = ex.index.isin(psi_cbl.index).astype(int)
    ex.to_csv(os.path.join(OUT, 'exons_features.tsv'), sep='\t')
    psi.to_parquet(os.path.join(OUT, 'psi_ctx.parquet')); psi_cbl.to_parquet(os.path.join(OUT, 'psi_cbl.parquet'))
    meta.index = psi.columns if len(meta) == psi.shape[1] else meta.index
    meta.to_csv(os.path.join(OUT, 'meta_ctx.tsv'), sep='\t'); meta_cbl.to_csv(os.path.join(OUT, 'meta_cbl.tsv'), sep='\t')
    print(ex.describe().T[['mean', '50%']])

if __name__ == '__main__':
    main()
