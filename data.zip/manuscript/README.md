# manuscript/
Sources of the Supplementary Information (pandoc >= 3.1):
    pandoc supplementary.md --citeproc --reference-doc=reference_clean.docx -o Supplementary_Information.docx
refs.json: CSL-JSON bibliography verified against Crossref; nature.csl: citation style.
The main article is maintained as a Word document (submission version).
