---
title: "Supplementary Information"
subtitle: "How an under-pruned cortex rewrites its splicing code: Ca²⁺-tuned condensates outcompete transcription-speed and mechanical routes in idiopathic autism"
bibliography: refs.json
csl: nature.csl
link-bibliography: false
---

Ysaías J. Alvarado¹, Máximo Quintero^2,3^, Arlene Cardozo-Urdaneta¹, Carla Lossada¹, Yovani Marrero-Ponce^4,5^, Félix Martinez-Rios⁴, Yunierkis Pérez-Castillo⁶, Ariana Delgado^1,\*^ and Lenin González-Paz^1,\*^

\*Correspondence: lgonzalezpaz@gmail.com (L.G.-P.); arianadelg@gmail.com (A.D.)

Reference numbers refer to the reference list of this document.

# Supplementary Methods

## Software, inputs and execution

All analyses are implemented in twelve numbered Python scripts executed by `run_all.sh` (Python 3.13; NumPy 2.5, SciPy 1.18, pandas 3.0, statsmodels 0.15, scikit-learn 1.9, SALib 1.6, Matplotlib 3.11, pyreadr 0.5, py2bit 1.0, pdfplumber 0.11) [@harris2020; @virtanen2020; @seabold2010; @pedregosa2011; @herman2017; @iwanaga2022; @hunter2007]. `00_download_data.py` retrieves every input from its public location at a pinned commit or archive and verifies SHA-256 checksums (Supplementary Table 1; file `data/checksums.sha256`). Random seeds are fixed in every script (exon fingerprints: deterministic folds; transfer-function calibration 314; model selection 20261019; donor tests 7; biophysics 42; mechanics and Sobol sampling seeded within `08_biophysics.py`). The complete pipeline runs in about 20–25 min on a two-core laptop with 8 GB RAM, the most expensive steps being per-exon donor-clustered regressions and the 40,000-draw prior-predictive simulation.

## Exon coordinates and features

Event identifiers of Parikshak et al. [@parikshak2016] follow the rMATS convention: exon start 0-based, end 1-based, and the "upstream" and "downstream" flanking exons named by genomic position. On the minus strand the transcript-upstream exon is therefore the genomic downstream flank, and all sequences were reverse-complemented before scoring. Of 500 randomly sampled exons, 489 had canonical AG acceptor and GT donor dinucleotides under this convention. MaxEntScan scores were computed with the original maximum-entropy models (23-nt 3′ splice-site windows, 20 intronic + 3 exonic nucleotides; 9-nt 5′ windows, 3 exonic + 6 intronic) [@yeo2004]. Non-cassette events (alternative 5′/3′ sites, mutually exclusive exons) present in the source files were not analysed.

## Cross-species mapping

Mouse exons were lifted to hg19 with the UCSC liftOver binary (`-minMatch=0.5`) [@kent2002]; KCl exons (mm39) were first lifted to mm10. Of 140 parsed *Srrm4*-dependent alternative exons, 3,615 slow-Pol II events and 986 KCl exons that lifted, 99, 1,431 and 620 were matched to a human cassette exon with reciprocal overlap ≥0.5. Within the analysed cortical set (13,975 exons) these numbers were 92, 1,036 (motor-neuron ΔPSI available) and 509. Event lists, matched coordinates and per-exon annotations are provided in `data/processed/mouse_sets_hg19.tsv`.

## Fingerprint models

The E-score model is an L2-penalized logistic regression (inverse regularization *C* = 0.3, balanced class weights) on 15 standardized features. Its training universe is the set of human cassette exons with an orthologous VAST-TOOLS event in either mouse dataset (1,452 exons, of which 94 have reduced inclusion in *Srrm4*-mutant brain). The K-score is a ridge regression (α = 10) of slow-Pol II motor-neuron ΔPSI on the same features (1,343 exons). Cross-validation used `GroupKFold` with five folds, grouping exons by locus. Loci were defined as connected components of overlapping flanking-exon spans on each chromosome (8,682 loci among the analysed exons). The D-score (neuronal-differentiation axis) is a ridge model of wild-type motor neuron versus embryonic stem cell ΔPSI. Feature weights are given in Supplementary Table 2.

## Donor-clustered inference

For each exon, the CR1 cluster-robust variance of the diagnosis coefficient was

$$\widehat{Var}(\hat\beta_j)=\frac{G}{G-1}\,\frac{n-1}{n-k}\sum_{g=1}^{G}\Big(\sum_{i\in g} a_{ji}\,\hat\varepsilon_i\Big)^2,\qquad \mathbf{a}_j=\big[(\mathbf{X}^\top \mathbf{X})^{-1}\mathbf{X}^\top\big]_{j\cdot} \qquad\qquad (S1)$$

with *G* donors, *n* samples and *k* regressors, and *t* statistics were referred to *G* − 1 degrees of freedom [@colincameron2015].

## Intraclass correlation

The within-locus ICC of exon *z* scores was estimated from one-way analysis of variance for unbalanced groups:

$$ICC = \frac{MS_B - MS_W}{MS_B + (n_0-1)\,MS_W},\qquad n_0=\frac{1}{L-1}\left(N-\frac{\sum_\ell n_\ell^2}{N}\right) \qquad\qquad (S2)$$

over the *L* loci with ≥2 analysed exons (*N* exons in total). The null distribution was obtained by permuting locus labels (200 permutations).

## Activity load and energetic feasibility

The mean-field activity map (equation 1) treats recurrent drive as a power of synapse density (supralinearity *q*), divided by a homeostatic brake whose set point is engaged through the same Ca²⁺/CaMK activation function *A*(*C*) that inactivates the scaffold [@turrigiano1998; @hengen2013]. Its parameters were given broad uniform priors (main-text Table 1). Equation 1 was solved by Brent's method on [10⁻⁴, 10⁴]. Because the right-hand side is monotone in *C* for κ < 1, the solution is unique. The relative ATP demand (equation 2) scales synaptic costs (58% of signalling ATP) with both synapse number and activity, action-potential costs (22%) with activity, and resting-potential costs (20%) not at all [@harris2012; @howarth2012]. The energetic feasibility statistic is the fraction of prior draws in which adolescent demand exceeds the spare respiratory capacity [@yadava2007] in the absence of adaptation.

## Condensate model: derivation and emergent ultrasensitivity

For a scaffold at total concentration *c* partitioning between a dilute phase (concentration *c*~sat~) and a dense phase (concentration *c*~den~ ≫ *c*), the lever rule gives a dense-phase volume fraction (*c* − *c*~sat~)/(*c*~den~ − *c*~sat~) ≈ (*c* − *c*~sat~)/*c*~den~ [@flory1942; @riback2020]. The condensed amount is therefore proportional to *c* − *c*~sat~ above saturation and zero below it. Writing *c* = *s ρ*~0~ *c*~sat,0~ and normalizing to the baseline condensed amount yields equation 5. Phosphorylation of RS-type sticker residues reduces the effective interaction energy; to first order the logarithm of *c*~sat~ is linear in the phosphorylated fraction, giving the exponential factor e^γ(φ−φ0)^. The apparent Hill coefficient of the composite transfer function *I*(*s*) (equation 6) was estimated by non-linear least squares (`scipy.optimize.curve_fit`) of $I(s)=I_m s^h/(K^h+s^h)$ over 400 points in *s* ∈ [0.02, 2], with bounds *h* ∈ [0.5, 40] and *K* ∈ [10⁻³, 2].

## Donor-level microexon inclusion in PSI units

For the transfer-function calibration, the per-sample mean PSI of the 208 neural microexons was regressed on diagnosis, age, region, RNA integrity and the five composition scores; covariate contributions (centred) were subtracted while the diagnosis effect was retained, and samples were averaged per donor. Per-neuron SRRM4/SRRM3 expression is the mean of the two log~2~ expression values residualized on the neuronal marker score, age and region. The mixture was fitted by maximum likelihood (Nelder–Mead, four starting values of δ), and its 95% intervals were obtained from 400 bootstrap resamples of donors within each group. The width of the δ interval set the standard deviation of the δ likelihood term.

## Elongation calibration

Elongation rates measured by 4sU-DRB in wild-type and homozygous slow Pol II cells [@maslon2019] were paired by transcript (123 transcripts with rates in both genotypes). The median ratio was 0.749 (Δln *v* = −0.289). The microexon sensitivity ∂PSI/∂ln *v* = 0.137 is the median slow-Pol II motor-neuron ΔPSI of human-matched microexons (−3.97 percentage points; bootstrap 95% CI −8.39 to −1.63; *n* = 95) divided by Δln *v*.

## Subgroup simulation

For each of 1,000 accepted H-E(Ca²⁺) draws, 2,000 virtual adolescents received a spine ratio drawn from 𝒩(1.655, (0.088·√5)²), truncated below at 0.8, and an individual supersaturation ρ~0,i~ = ρ~0~ 2^*x*~i~^, *x*~i~ ~ 𝒩(0, σ²). Individuals with ρ~0,i~ > 1 (condensate-competent at baseline) whose condensed amount fell below half of their own baseline were counted as having crossed the threshold. σ = 0.300 is the standard deviation across control donors of composition-adjusted log~2~ SRRM4 expression (residuals of SRRM4 on neuronal score, age and region, averaged per donor).

## Mechanical bound

Equation 10 treats each elimination contact as a point force applied at the spine and transmitted along the dendrite with exponential attenuation (shear-lag behaviour of an anchored viscoelastic cable [@otoole2008; @bernal2007]). Concurrent contacts are randomly oriented, so their resultant scales as √*n*. The bound ignores viscous dissipation, cytoskeletal remodelling and the buffering of forces by the soma, and compares the transmitted force with the basal actomyosin load on the nucleus [@lammerding2011; @guilluy2014]. Even so, 94.6% of 200,000 log-uniform draws fell below 5% of the basal load.

# Supplementary Tables

The complete numerical results are provided as **Supplementary Data** (`Supplementary_Data.xlsx`, sheets S1–S16), and per-exon source data as `Source_Data_exon_level.csv.gz`. Selected tables are reproduced below.

**Supplementary Table 1. Public data sources (pinned versions).**

| Data | Reference | Location (pinned version) | Files / values |
|------------------------------|--------------------------|----------------------------------------|--------------------------|
| Cassette-exon PSI, cortex and cerebellar vermis | Parikshak et al. 2016 Nature 540:423 | github.com/dhglab/Genome-wide-changes-in-lncRNA-alternative-splicing-and-cortical-patterning-in-autism (commit b9c61ac) | ASD_PSI_Data.Rdata; SuppTable2A.csv |
| Cortical bulk RNA-seq (composition, activity, OXPHOS indices) | Gandal et al. 2022 Nature 611:532 | github.com/dhglab/Broad-transcriptomic-dysregulation-across-the-cerebral-cortex-in-ASD (commit 6821cc5) | 02_01_A_AllProcessedData_wModelMatrix.RData |
| Srrm4-mutant splicing changes (cortex, hippocampus) | Quesnel-Vallieres et al. 2015 Genes Dev 29:746 | Europe PMC PMC4387716 | Table S2 |
| Slow (R749H) Pol II splicing changes; elongation rates; expression | Maslon et al. 2019 EMBO J 38:e101244 | Europe PMC PMC6484407 | Tables EV1, EV2, EV3 |
| KCl-responsive exons in primary neurons | Krick et al. 2025 Genome Res 35:1301 | Europe PMC PMC12129014 | Supplementary Table 9 |
| Spine density, ASD/control | Tang et al. 2014 Neuron 83:1131 | published values | ratios 1.084 +/- 0.037 (2-9 y), 1.655 +/- 0.088 (13-20 y) |
| Neocortical ATP budget | Harris, Jolivet & Attwell 2012 Neuron 75:762 | published values | housekeeping 25%; synaptic 58%, AP 22%, resting 20% of signalling |
| hg19 sequence; liftOver chains and binary | Kent et al. 2002 Genome Res 12:996 | hgdownload.soe.ucsc.edu | hg19.2bit; mm9ToHg19, mm10ToHg19, mm39ToMm10 chains |
| Lamina-associated domains (Tig3 fibroblasts) | Guelen et al. 2008 Nature 453:948 | api.genome.ucsc.edu track laminB1Lads (hg19) | laminB1Lads_hg19.tsv |
| MaxEntScan splice-site models | Yeo & Burge 2004 J Comput Biol 11:377 | github.com/kepbod/maxentpy (commit b5e69aa) | me2x5, splice5sequences, me2x3acc |

**Supplementary Table 2. Feature weights of the exon fingerprints.** E-score: standardized coefficients of the L2-logistic model of *Srrm4* dependence (cross-validated AUC 0.80). K-score: standardized ridge coefficients for slow-Pol II motor-neuron ΔPSI (cross-validated Spearman ρ = 0.20).

| Feature | E-score weight | K-score weight |
|----------------------------------|--------------|--------------|
| exon length (log10) | -0.765 | 0.005 |
| microexon (3–27 nt) | 0.153 | -0.012 |
| 3′ss MaxEnt | -0.602 | 0.009 |
| 5′ss MaxEnt | 0.189 | 0.013 |
| downstream-exon 3′ss | -0.067 | 9.20e-04 |
| upstream-exon 5′ss | -0.135 | -1.60e-04 |
| upstream intron (log10) | 0.174 | -0.010 |
| downstream intron (log10) | -0.410 | -0.008 |
| UGC per 100 nt (−60..−1) | 0.438 | -0.011 |
| pyrimidine fraction (−25..−3) | 0.494 | -0.004 |
| UGCAUG, downstream 300 nt | -0.213 | -0.018 |
| UGCAUG, upstream 300 nt | -0.091 | 0.002 |
| exon GC | -0.284 | 0.005 |
| flank GC (±200 nt) | -0.239 | -0.005 |
| frame-preserving | -0.079 | -0.005 |

**Supplementary Table 3. Donor-level tests.** Indices are means over donor samples of standardized residual inclusion. Mixture statistics refer to equation 12 with one component fixed at the control distribution (bootstrap *P*, 500 replicates). Coupling coefficients are standardized regressions within each group adjusted for neuronal content and age.

| Index | ASD − CTL | t | P | Skew (ASD) | Mixture LRT | P (bootstrap) | π |
|--------------|----------|--------|--------|----------|----------|------------|--------|
| Scaffold | -0.046 | -2.823 | 0.006 | -1.150 | 30.656 | 0.028 | 0.295 |
| Elongation | 0.016 | 1.352 | 0.180 | -0.351 | 7.977 | 0.106 | 0.501 |
| Microexon | -0.067 | -2.448 | 0.017 | -0.902 | 25.079 | 0.022 | 0.280 |


**Supplementary Table 3b. Coupling of donor indices to activity, oxidative-phosphorylation and Ca²⁺/kinase indices** (standardized coefficients within group, adjusted for neuronal content and age).

| Index | Group | β IEG | P (IEG) | β OXPHOS | P (OXPHOS) | β Ca²⁺/kinase | P (Ca²⁺/kinase) |
|------------|--------|---------|---------|----------|----------|------------|------------|
| Scaffold | ASD | -0.112 | 0.559 | -0.132 | 0.660 | 0.031 | 0.933 |
| Scaffold | CTL | -0.011 | 0.957 | -0.283 | 0.104 | 0.012 | 0.946 |
| Elongation | ASD | 0.241 | 0.191 | 0.178 | 0.540 | -0.132 | 0.708 |
| Elongation | CTL | -0.004 | 0.983 | -0.324 | 0.064 | -0.179 | 0.316 |
| Microexon | ASD | -0.395 | 0.024 | -0.268 | 0.343 | 0.574 | 0.088 |
| Microexon | CTL | -0.394 | 0.043 | 0.126 | 0.473 | 0.355 | 0.041 |

**Supplementary Table 4. ABC posterior summaries for the transduction channels** (rejection within a two-standard-error ellipse around the ≤10-year and 10–30-year neural-microexon deficits; 40,000 prior draws).

| Channel | Parameter | Accepted draws | Prior median | Posterior median | 5% | 95% |
|------------------|------------|----------|----------|------------|--------|--------|
| H-E Ca²⁺ | gamma | 1469 | 2.736 | 1.059 | 0.532 | 3.390 |
| H-E Ca²⁺ | rho0 | 1469 | 2.611 | 3.286 | 2.058 | 3.938 |
| H-E Ca²⁺ | phi0 | 1469 | 0.273 | 0.119 | 0.054 | 0.400 |
| H-E ATP | SRC | 7638 | 2.152 | 2.387 | 1.552 | 2.946 |
| H-E ATP | chronic | 7638 | 0.449 | 0.696 | 0.186 | 0.879 |
| H-E ATP | mu | 7638 | 1.502 | 1.123 | 0.192 | 2.720 |
| H-K (sign-agnostic) | kv_sym | 9014 | 0.002 | -0.343 | -0.646 | -0.120 |

**Supplementary Table 5. Sobol sensitivity indices** (Saltelli scheme, 512 base samples, 15 parameters) for the adolescent H-E microexon deficit (`HE_adol`) and the adolescent ATP ratio (`atp_adol`).

| Output | Parameter | S₁ | S_T | S_T 95% conf. |
|----------------------|------------|--------|--------|----------|
| H-E adolescent ΔPSI | gamma | 0.193 | 0.434 | 0.091 |
| H-E adolescent ΔPSI | phi0 | 0.086 | 0.272 | 0.075 |
| H-E adolescent ΔPSI | rho0 | 0.046 | 0.232 | 0.065 |
| H-E adolescent ΔPSI | KC | 0.021 | 0.177 | 0.057 |
| H-E adolescent ΔPSI | chronic | 0.051 | 0.154 | 0.059 |
| H-E adolescent ΔPSI | q | 0.029 | 0.151 | 0.046 |
| H-E adolescent ΔPSI | SRC | 0.031 | 0.136 | 0.049 |
| H-E adolescent ΔPSI | n | 0.039 | 0.130 | 0.045 |
| Adolescent ATP ratio | chronic | 0.407 | 0.527 | 0.080 |
| Adolescent ATP ratio | SRC | 0.255 | 0.454 | 0.067 |
| Adolescent ATP ratio | q | 0.060 | 0.197 | 0.042 |
| Adolescent ATP ratio | Nadol | 0.076 | 0.134 | 0.028 |
| Adolescent ATP ratio | kappa | 0.019 | 0.056 | 0.017 |
| Adolescent ATP ratio | KC | 0.020 | 0.018 | 0.008 |
| Adolescent ATP ratio | eta | 8.13e-04 | 0.015 | 0.006 |
| Adolescent ATP ratio | Cb | 6.40e-04 | 0.013 | 0.005 |

**Supplementary Table 6. Within-locus coherence (ICC) of ASD splicing changes.**

| Signal | ICC | Loci | Exons | Null mean | Null s.d. | P (permutation) |
|------------------------------|--------|--------|--------|----------|----------|----------|
| raw z | 0.190 | 2781 | 8074 | -4.70e-04 | 0.011 | 0.005 |
| residual after cis-scores (E, K) + baseline PSI | 0.183 | 2781 | 8074 | -3.55e-04 | 0.011 | 0.005 |
| high \|K\| exons | 0.227 | 469 | 1096 | — | — | — |
| low \|K\| exons | 0.189 | 1999 | 5531 | — | — | — |

**Supplementary Table 7. Logistic models of KCl responsiveness** among orthologous frameshifting exons (odds ratios per standard deviation of the fingerprint).

| Model | Exons | KCl-responsive | AIC | OR (E) | P (E) | OR (K) | P (K) |
|--------|--------|----------|----------|--------|--------|--------|--------|
| E | 817 | 509 | 1082.750 | 1.098 | 0.173 | — | — |
| K | 817 | 509 | 1003.631 | — | — | 0.523 | 4.25e-16 |
| E+K | 817 | 509 | 1003.626 | 0.894 | 0.156 | 0.506 | 4.07e-16 |

**Supplementary Table 8. Splicing-factor expression in ASD cortex, bulk and composition-adjusted** (725 samples, 103 donors, 11 regions; donor-clustered errors). Marker scores are in s.d. units.

| Gene | Model | log₂FC | s.e. | P | Samples | Donors |
|----------|----------------------|--------|--------|--------|--------|--------|
| SRRM4 | bulk | -0.177 | 0.064 | 0.007 | 725 | 103 |
| SRRM4 | composition-adjusted | 7.39e-04 | 0.044 | 0.987 | 725 | 103 |
| SRRM3 | bulk | -0.062 | 0.076 | 0.415 | 725 | 103 |
| SRRM3 | composition-adjusted | -0.058 | 0.062 | 0.355 | 725 | 103 |
| RBFOX1 | bulk | -0.337 | 0.085 | 1.41e-04 | 725 | 103 |
| RBFOX1 | composition-adjusted | -0.058 | 0.036 | 0.111 | 725 | 103 |
| SRSF11 | bulk | -0.025 | 0.031 | 0.424 | 725 | 103 |
| SRSF11 | composition-adjusted | -0.047 | 0.032 | 0.139 | 725 | 103 |
| RNPS1 | bulk | -0.083 | 0.021 | 1.60e-04 | 725 | 103 |
| RNPS1 | composition-adjusted | -0.018 | 0.014 | 0.217 | 725 | 103 |
| CPEB4 | bulk | 0.042 | 0.032 | 0.190 | 725 | 103 |
| CPEB4 | composition-adjusted | 0.030 | 0.031 | 0.345 | 725 | 103 |
| NOVA2 | bulk | -0.087 | 0.053 | 0.101 | 725 | 103 |
| NOVA2 | composition-adjusted | -0.033 | 0.046 | 0.481 | 725 | 103 |
| PTBP2 | bulk | -0.078 | 0.044 | 0.080 | 725 | 103 |
| PTBP2 | composition-adjusted | -0.030 | 0.032 | 0.348 | 725 | 103 |
| neuron | marker score (s.d.) | -0.423 | 0.106 | 1.20e-04 | 725 | 103 |
| astro | marker score (s.d.) | 0.427 | 0.146 | 0.004 | 725 | 103 |

**Supplementary Table 9. Donor-level microexon deficit and calibration of the scaffold–microexon transfer function.**

| Quantity | Value |
|----------------------------------------|----------------------|
| Neural microexons (control PSI > 0.5) | 208 |
| Control donors / ASD donors | 44 / 38 |
| Control neural-microexon PSI (mean ± s.d.) | 0.784 ± 0.017 |
| Subgroup fraction π (mixture) | 0.297 |
| Subgroup shift δ (PSI; 95% bootstrap CI) | -0.028 (-0.069, -0.004) |
| Likelihood-ratio statistic | 21.52 |
| Slope, controls (PSI per log₂ unit; P) | 0.0068 ± 0.0074; 0.36 |
| Slope, ASD (PSI per log₂ unit; P) | 0.0149 ± 0.0080; 0.07 |
| Hill coefficient h (median; 95% interval) | 7.4 (1.9–14.6) |
| Half-saturation K (median; 95% interval) | 0.24 (0.05–0.57) |
| Subgroup scaffold activity φ_d (median; 95% interval) | 0.66 (0.19–0.98) |


# Supplementary Figures

![**Supplementary Figure 1. Additional tests.** **a**, Within-locus intraclass correlation of ASD exon *z*-scores: raw, after removing the fingerprints and baseline PSI, and for exons with high or low elongation sensitivity |K|; points, permutation null (mean ± 2 s.d.). **b**, ΔAIC of logistic models predicting KCl-responsive frameshifting exons from the E-score, K-score or both. **c**, Total (light) and first-order (dark) Sobol indices of the adolescent ATP ratio. **d**, Emergent Hill coefficient of the lever-rule transfer function as a function of baseline supersaturation ρ~0~ (colour, intrinsic cooperativity *h*~0~).](../figures/FigureS1.png){width=17cm}

![**Supplementary Figure 2. The microexon deficit of ASD cortex is post-transcriptional, switch-like and ultrasensitive.** **a**, ASD log~2~ fold changes (±95% CI, donor-clustered) of splicing-factor transcripts in bulk cortex (grey) and after adjustment for cell-type composition (blue). **b**, Donor-level neural-microexon PSI (composition-adjusted) in controls and ASD, with the control fit and the mixture statistics (π, δ with 95% bootstrap CI). **c**, Within-group dose–response of microexon inclusion on per-neuron SRRM4/SRRM3 expression. **d**, Posterior distribution of the Hill coefficient of the scaffold–microexon transfer function (grid posterior; dashed line, median).](../figures/FigureS2.png){width=17cm}

# Supplementary References

::: {#refs}
:::
