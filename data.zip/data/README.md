# data/

* `checksums.sha256` – SHA-256 checksums of every analysed input (paths relative to `data/raw/`).
* `raw/` – created by `code/00_download_data.py` (not distributed; all inputs are public, see the main README).
* `processed/` – intermediate files created by steps 01–03 (exon features, lifted mouse exon sets, cached PSI/expression matrices).

Coordinates are hg19. Cassette-exon identifiers follow the rMATS convention of Parikshak et al. (2016):
`chr-str[±]-eS-<0-based start>-eE-<end>-ueS-…-ueE-…-deS-…-deE-…`, where "u" and "d" denote the genomic lower and higher flanking exons.
